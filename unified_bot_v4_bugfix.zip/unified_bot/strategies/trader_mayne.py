"""
Strategy 3 — Trader Mayne "Structure & OTE"
FIXES: BUG 1 (two-sided swing), BUG 2 (real unbroken HTF target),
       BUG 3 (separate bull/bear MSB trackers), BUG 9 (OB_LOOKBACK 5→10)
"""
import os, logging
from datetime import datetime, timezone
from dataclasses import dataclass
from typing import Optional
import pandas as pd

log = logging.getLogger("S3-MAYNE")

SYMBOLS            = ["XAUUSDT", "BTCUSDT"]
HTF                = "1d"
LTF                = "30m"
SWING_LOOKBACK     = int(float(os.getenv("TM_SWING_LOOKBACK",   "10")))
OB_LOOKBACK        = int(float(os.getenv("TM_OB_LOOKBACK",      "10")))  # BUG 9 FIX: 5→10
SWEEP_BUFFER_PCT   = float(os.getenv("TM_SWEEP_BUFFER_PCT",     "0.05"))
OB_ZONE_BUFFER_PCT = float(os.getenv("TM_OB_ZONE_BUFFER_PCT",   "0.20"))
MIN_RR             = float(os.getenv("TM_MIN_RR",               "2.0"))
POLL_INTERVAL      = int(float(os.getenv("TM_POLL_INTERVAL",    "300")))

_fired: dict[str, str] = {}

@dataclass
class MSBResult:
    direction: str; msb_price: float; msb_bar: int
    swing_origin: float; swing_end: float; midpoint: float
    ob_high: float; ob_low: float; ob_bar: int; ext_target: float

@dataclass
class LTFConfirmation:
    swept_price: float; entry: float; stop_loss: float

@dataclass
class Signal:
    symbol: str; direction: str; entry: float; stop_loss: float
    take_profit: float; rr: float; msb_price: float
    ob_high: float; ob_low: float; midpoint: float
    swept_price: float; ext_target: float; timestamp: str

def _raw_to_df(raw: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(raw)
    df = df.iloc[:-1].copy()
    df.rename(columns={"ts": "open_time", "vol": "volume"}, inplace=True)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df.set_index("open_time", inplace=True)
    return df[["open", "high", "low", "close", "volume"]]

def _swing_highs(df: pd.DataFrame, lookback: int) -> list[tuple[int, float]]:
    # BUG 1 FIX — two-sided window
    highs, n, out = df["high"].values, len(df["high"].values), []
    for i in range(lookback, n - lookback):
        if highs[i] >= max(highs[i - lookback: i + lookback + 1]):
            out.append((i, highs[i]))
    return out

def _swing_lows(df: pd.DataFrame, lookback: int) -> list[tuple[int, float]]:
    # BUG 1 FIX — two-sided window
    lows, n, out = df["low"].values, len(df["low"].values), []
    for i in range(lookback, n - lookback):
        if lows[i] <= min(lows[i - lookback: i + lookback + 1]):
            out.append((i, lows[i]))
    return out

def _calc_rr(entry, stop, tp):
    risk = abs(entry - stop); reward = abs(tp - entry)
    return round(reward / risk, 2) if risk > 0 else 0.0

def _last_unbroken_swing_high(sh_list, closes, after_bar) -> Optional[float]:
    # BUG 2 FIX — real HTF target: nearest unbroken swing high above current price
    current = closes[-1]
    for bar, price in reversed(sh_list):
        if bar <= after_bar: break
        if price <= current: continue
        if not any(c >= price for c in closes[bar + 1:]):
            return price
    return None

def _last_unbroken_swing_low(sl_list, closes, after_bar) -> Optional[float]:
    # BUG 2 FIX — real HTF target: nearest unbroken swing low below current price
    current = closes[-1]
    for bar, price in reversed(sl_list):
        if bar <= after_bar: break
        if price >= current: continue
        if not any(c <= price for c in closes[bar + 1:]):
            return price
    return None

def _detect_msb(htf_df: pd.DataFrame) -> Optional[MSBResult]:
    # BUG 3 FIX — independent bull/bear trackers; return most recent
    closes = htf_df["close"].values.tolist()
    highs  = htf_df["high"].values
    lows   = htf_df["low"].values
    opens  = htf_df["open"].values
    n      = len(htf_df)
    sh_list = _swing_highs(htf_df, SWING_LOOKBACK)
    sl_list = _swing_lows(htf_df,  SWING_LOOKBACK)
    search_start = max(SWING_LOOKBACK * 2 + 5, n - 30)

    best_bull = None; best_bull_bar = -1
    best_bear = None; best_bear_bar = -1

    for i in range(search_start, n):
        body_pct = abs(closes[i] - opens[i]) / max(opens[i], 1e-9) * 100

        broken_sh = [sh for sh in sh_list if sh[0] < i - 2 and sh[1] < closes[i]]
        if broken_sh and body_pct > 0.3:
            sh_bar, sh_price = broken_sh[-1]
            sl_before = [sl for sl in sl_list if sl[0] < sh_bar]
            if sl_before:
                sl_bar, sl_price = sl_before[-1]
                midpoint = (sh_price + sl_price) / 2
                ob_bar = next((j for j in range(sh_bar, max(sh_bar - OB_LOOKBACK, sl_bar), -1)
                               if closes[j] < opens[j]), max(sh_bar - 1, 0))
                ob_bar = max(ob_bar, 0)
                ext_target = _last_unbroken_swing_high(sh_list, closes, i) or sh_price * 1.02
                best_bull = MSBResult("bullish", sh_price, i, sl_price, sh_price, midpoint,
                                      highs[ob_bar], lows[ob_bar], ob_bar, ext_target)
                best_bull_bar = i

        broken_sl = [sl for sl in sl_list if sl[0] < i - 2 and sl[1] > closes[i]]
        if broken_sl and body_pct > 0.3:
            sl_bar, sl_price = broken_sl[-1]
            sh_before = [sh for sh in sh_list if sh[0] < sl_bar]
            if sh_before:
                sh_bar, sh_price = sh_before[-1]
                midpoint = (sh_price + sl_price) / 2
                ob_bar = next((j for j in range(sl_bar, max(sl_bar - OB_LOOKBACK, sh_bar), -1)
                               if closes[j] > opens[j]), max(sl_bar - 1, 0))
                ob_bar = max(ob_bar, 0)
                ext_target = _last_unbroken_swing_low(sl_list, closes, i) or sl_price * 0.98
                best_bear = MSBResult("bearish", sl_price, i, sh_price, sl_price, midpoint,
                                      highs[ob_bar], lows[ob_bar], ob_bar, ext_target)
                best_bear_bar = i

    if best_bull is None and best_bear is None: return None
    if best_bull is None: return best_bear
    if best_bear is None: return best_bull
    return best_bull if best_bull_bar >= best_bear_bar else best_bear

def _price_in_ote_and_ob(price: float, msb: MSBResult) -> bool:
    in_ob = msb.ob_low <= price <= msb.ob_high
    if msb.direction == "bullish": return price < msb.midpoint and in_ob
    return price > msb.midpoint and in_ob

def _detect_ltf_breaker(ltf_df: pd.DataFrame, msb: MSBResult) -> Optional[LTFConfirmation]:
    highs, lows, closes = ltf_df["high"].values, ltf_df["low"].values, ltf_df["close"].values
    n = len(ltf_df)
    buf = closes[-1] * SWEEP_BUFFER_PCT / 100
    scan_start = max(SWING_LOOKBACK + 3, n - 30)

    if msb.direction == "bullish":
        for sl_bar, sl_price in reversed([(i, p) for i, p in _swing_lows(ltf_df, 3) if i >= scan_start]):
            for i in range(sl_bar + 1, n - 1):
                if lows[i] < sl_price - buf and closes[i] > sl_price:
                    sh_before = [(j, p) for j, p in _swing_highs(ltf_df, 3) if sl_bar <= j < i]
                    if not sh_before: continue
                    _, ltf_sh_price = sh_before[-1]
                    for k in range(i + 1, min(i + 6, n)):
                        if closes[k] > ltf_sh_price:
                            return LTFConfirmation(lows[i], closes[k], lows[i] * 0.999)
    else:
        for sh_bar, sh_price in reversed([(i, p) for i, p in _swing_highs(ltf_df, 3) if i >= scan_start]):
            for i in range(sh_bar + 1, n - 1):
                if highs[i] > sh_price + buf and closes[i] < sh_price:
                    sl_before = [(j, p) for j, p in _swing_lows(ltf_df, 3) if sh_bar <= j < i]
                    if not sl_before: continue
                    _, ltf_sl_price = sl_before[-1]
                    for k in range(i + 1, min(i + 6, n)):
                        if closes[k] < ltf_sl_price:
                            return LTFConfirmation(highs[i], closes[k], highs[i] * 1.001)
    return None

def _format_signal(sig: Signal) -> str:
    emoji  = "🟢" if sig.direction == "BUY" else "🔴"
    arrow  = "📈" if sig.direction == "BUY" else "📉"
    d      = "━━━━━━━━━━━━━━━━━━━━━"
    zone   = "DISCOUNT (below 50%)" if sig.direction == "BUY" else "PREMIUM (above 50%)"
    ob_lbl = "Bullish OB" if sig.direction == "BUY" else "Bearish OB"
    if sig.direction == "BUY":
        logic = (f"  1️⃣ Bullish MSB confirmed on Daily\n"
                 f"  2️⃣ Range midpoint: {sig.midpoint:.4f} — DISCOUNT zone\n"
                 f"  3️⃣ Bullish OB: {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
                 f"  4️⃣ Price in OB inside discount zone\n"
                 f"  5️⃣ 30m: Swing low swept → MSB up → Breaker entry\n"
                 f"  🎯 Target: Next HTF swing high at {sig.ext_target:.4f}")
    else:
        logic = (f"  1️⃣ Bearish MSB confirmed on Daily\n"
                 f"  2️⃣ Range midpoint: {sig.midpoint:.4f} — PREMIUM zone\n"
                 f"  3️⃣ Bearish OB: {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
                 f"  4️⃣ Price in OB inside premium zone\n"
                 f"  5️⃣ 30m: Swing high swept → MSB down → Breaker entry\n"
                 f"  🎯 Target: Next HTF swing low at {sig.ext_target:.4f}")
    return (f"{emoji} <b>[S3] STRUCTURE &amp; OTE</b> {arrow}\n"
            f"<i>Trader Mayne — MSB → OB → Breaker</i>\n{d}\n"
            f"🪙 <b>Symbol   :</b> {sig.symbol}\n📊 <b>Direction:</b> {sig.direction}\n"
            f"⏱ <b>TF       :</b> 1D HTF | 30m LTF\n📍 <b>OTE Zone :</b> {zone}\n{d}\n"
            f"🎯 <b>Entry    :</b> {sig.entry:.4f}\n🛑 <b>Stop Loss:</b> {sig.stop_loss:.4f}\n"
            f"✅ <b>Take Profit:</b> {sig.take_profit:.4f}\n📐 <b>R:R      :</b> 1:{sig.rr:.1f}\n{d}\n"
            f"🔱 <b>HTF MSB Level :</b> {sig.msb_price:.4f}\n"
            f"📦 <b>{ob_lbl} Zone  :</b> {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
            f"💧 <b>LTF Swept Level:</b> {sig.swept_price:.4f}\n"
            f"🏁 <b>HTF Target     :</b> {sig.ext_target:.4f}\n{d}\n"
            f"📋 <b>Setup Gates (Trader Mayne):</b>\n{logic}\n{d}\n"
            f"⏰ <b>Time (UTC):</b> {sig.timestamp}\n"
            f"⚠️ <i>Signal only — not financial advice.</i>")

def _analyse(symbol: str, fetch_fn) -> Optional[Signal]:
    log.info(f"[{symbol}] Scanning ...")
    raw_htf = fetch_fn(symbol, HTF, limit=120)
    raw_ltf = fetch_fn(symbol, LTF, limit=100)
    if not raw_htf or not raw_ltf:
        log.warning(f"[{symbol}] Data fetch failed."); return None
    htf_df = _raw_to_df(raw_htf)
    ltf_df = _raw_to_df(raw_ltf)
    if len(htf_df) < SWING_LOOKBACK * 2 + 15 or len(ltf_df) < SWING_LOOKBACK * 2 + 10:
        log.warning(f"[{symbol}] Insufficient bars."); return None
    current_price = ltf_df["close"].iloc[-1]
    log.info(f"[{symbol}] Price: {current_price:.4f}")
    msb = _detect_msb(htf_df)
    if msb is None:
        log.info(f"[{symbol}] GATE 1 ✗ — No Daily MSB."); return None
    log.info(f"[{symbol}] GATE 1 ✓ — {msb.direction.upper()} MSB @ {msb.msb_price:.4f}")
    if not _price_in_ote_and_ob(current_price, msb):
        log.info(f"[{symbol}] GATE 2-4 ✗ — Price not in OB/OTE zone."); return None
    log.info(f"[{symbol}] GATE 2-4 ✓ — Inside OB + OTE zone.")
    confirm = _detect_ltf_breaker(ltf_df, msb)
    if confirm is None:
        log.info(f"[{symbol}] GATE 5 ✗ — No LTF breaker confirmed."); return None
    log.info(f"[{symbol}] GATE 5 ✓ — swept={confirm.swept_price:.4f} entry={confirm.entry:.4f}")
    direction = "BUY" if msb.direction == "bullish" else "SELL"
    rr = _calc_rr(confirm.entry, confirm.stop_loss, msb.ext_target)
    if rr < MIN_RR:
        log.info(f"[{symbol}] R:R {rr:.1f} < min {MIN_RR} — skipped."); return None
    key = f"{symbol}_{direction}_{msb.msb_bar}_{msb.ob_bar}"
    if _fired.get(symbol) == key:
        log.debug(f"[{symbol}] Already fired."); return None
    _fired[symbol] = key
    log.info(f"[{symbol}] ✅ {direction} entry={confirm.entry:.4f} SL={confirm.stop_loss:.4f} TP={msb.ext_target:.4f} R:R=1:{rr}")
    return Signal(symbol=symbol, direction=direction, entry=confirm.entry,
                  stop_loss=confirm.stop_loss, take_profit=msb.ext_target, rr=rr,
                  msb_price=msb.msb_price, ob_high=msb.ob_high, ob_low=msb.ob_low,
                  midpoint=msb.midpoint, swept_price=confirm.swept_price,
                  ext_target=msb.ext_target,
                  timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"))

def run(fetch_klines_fn) -> tuple[list[str], int]:
    messages = []
    log.info(f"── Mayne scan {datetime.now(timezone.utc).strftime("%H:%M UTC")} ──")
    for symbol in SYMBOLS:
        try:
            sig = _analyse(symbol, fetch_klines_fn)
            if sig: messages.append(_format_signal(sig))
        except Exception as exc:
            log.error(f"[{symbol}] Error: {exc}", exc_info=True)
    return messages, POLL_INTERVAL
