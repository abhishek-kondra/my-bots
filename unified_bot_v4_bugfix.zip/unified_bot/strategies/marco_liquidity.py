"""
Strategy 2 — Marco Trades "Liquidity Sweep"
FIXES: BUG 1 (two-sided swing), BUG 8 (stop buffer 0.15% → 0.30%)
"""
import os, logging
from datetime import datetime, timezone
from dataclasses import dataclass
from typing import Optional
import pandas as pd

log = logging.getLogger("S2-MARCO")

SYMBOLS               = ["XAUUSDT", "BTCUSDT"]
HTF                   = "30m"
LTF                   = "5m"
SESSION_START_UTC     = int(os.getenv("MARCO_SESSION_START",     "13"))
SESSION_END_UTC       = int(os.getenv("MARCO_SESSION_END",       "20"))
SWING_LOOKBACK        = int(float(os.getenv("SWING_LOOKBACK",    "10")))
SWEEP_BUFFER_PCT      = float(os.getenv("SWEEP_BUFFER_PCT",      "0.05"))
EQUAL_HL_TOL_PCT      = float(os.getenv("EQUAL_HL_TOL_PCT",      "0.10"))
CONFIRM_BARS          = int(float(os.getenv("CONFIRM_BARS",      "3")))
MIN_RR                = float(os.getenv("MIN_RR",                "2.0"))
POLL_INTERVAL         = int(float(os.getenv("POLL_INTERVAL",     "60")))
# BUG 8 FIX — raised from 0.15% to 0.30%
SWEEP_STOP_BUFFER_PCT = float(os.getenv("SWEEP_STOP_BUFFER_PCT", "0.30"))

_fired: dict[str, str] = {}

@dataclass
class SwingLevel:
    price: float; bar_index: int; level_type: str
    respected: bool = False; equal_cluster: bool = False

@dataclass
class Signal:
    symbol: str; direction: str; entry: float; stop_loss: float
    take_profit: float; rr: float; sweep_price: float; htf_target: float; timestamp: str

def _raw_klines_to_df(raw: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(raw)
    df = df.iloc[:-1].copy()
    df.rename(columns={"ts": "open_time", "vol": "volume"}, inplace=True)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df.set_index("open_time", inplace=True)
    return df[["open", "high", "low", "close", "volume"]]

def _find_swing_highs(df: pd.DataFrame) -> list[SwingLevel]:
    # BUG 1 FIX — two-sided window
    highs, n, result = df["high"].values, len(df["high"].values), []
    for i in range(SWING_LOOKBACK, n - SWING_LOOKBACK):
        window = highs[i - SWING_LOOKBACK: i + SWING_LOOKBACK + 1]
        if highs[i] >= max(window):
            result.append(SwingLevel(price=highs[i], bar_index=i, level_type="high"))
    return result

def _find_swing_lows(df: pd.DataFrame) -> list[SwingLevel]:
    # BUG 1 FIX — two-sided window
    lows, n, result = df["low"].values, len(df["low"].values), []
    for i in range(SWING_LOOKBACK, n - SWING_LOOKBACK):
        window = lows[i - SWING_LOOKBACK: i + SWING_LOOKBACK + 1]
        if lows[i] <= min(window):
            result.append(SwingLevel(price=lows[i], bar_index=i, level_type="low"))
    return result

def _mark_respected(df: pd.DataFrame, levels: list[SwingLevel]) -> list[SwingLevel]:
    closes = df["close"].values
    for lvl in levels:
        future = closes[lvl.bar_index + 1: lvl.bar_index + 6]
        if len(future) < 2: continue
        move_pct = abs(future[-1] - lvl.price) / lvl.price * 100
        if lvl.level_type == "high" and future[-1] < lvl.price and move_pct > 0.05:
            lvl.respected = True
        elif lvl.level_type == "low" and future[-1] > lvl.price and move_pct > 0.05:
            lvl.respected = True
    return levels

def _mark_equal_clusters(levels: list[SwingLevel]) -> list[SwingLevel]:
    prices = [lvl.price for lvl in levels]
    for lvl in levels:
        siblings = [p for p in prices if p != lvl.price
                    and abs(p - lvl.price) / lvl.price * 100 <= EQUAL_HL_TOL_PCT]
        if siblings: lvl.equal_cluster = True
    return levels

def _detect_sweep(df: pd.DataFrame, level: SwingLevel) -> Optional[dict]:
    highs, lows, closes = df["high"].values, df["low"].values, df["close"].values
    n = len(df)
    buf = level.price * SWEEP_BUFFER_PCT / 100
    for i in range(max(level.bar_index + 1, n - 15), n - 1):
        if level.level_type == "high":
            if highs[i] > level.price + buf and closes[i] < level.price and closes[i+1] < closes[i]:
                return {"bar": i, "sweep_price": highs[i], "entry": closes[i+1]}
        else:
            if lows[i] < level.price - buf and closes[i] > level.price and closes[i+1] > closes[i]:
                return {"bar": i, "sweep_price": lows[i], "entry": closes[i+1]}
    return None

def _get_htf_target(htf_df: pd.DataFrame, direction: str) -> Optional[float]:
    current = htf_df["close"].iloc[-1]
    if direction == "BUY":
        levels = _mark_equal_clusters(_mark_respected(htf_df, _find_swing_highs(htf_df)))
        candidates = [l for l in levels if l.respected and l.price > current]
        pool = [l for l in candidates if l.equal_cluster] or candidates
        return min(pool, key=lambda l: l.price).price if pool else None
    else:
        levels = _mark_equal_clusters(_mark_respected(htf_df, _find_swing_lows(htf_df)))
        candidates = [l for l in levels if l.respected and l.price < current]
        pool = [l for l in candidates if l.equal_cluster] or candidates
        return max(pool, key=lambda l: l.price).price if pool else None

def _rr(entry, stop, tp):
    risk = abs(entry - stop); reward = abs(tp - entry)
    return round(reward / risk, 2) if risk > 0 else 0.0

def _in_session():
    return SESSION_START_UTC <= datetime.now(timezone.utc).hour < SESSION_END_UTC

def _format_signal(sig: Signal) -> str:
    emoji = "🟢" if sig.direction == "BUY" else "🔴"
    arrow = "📈" if sig.direction == "BUY" else "📉"
    d = "━━━━━━━━━━━━━━━━━━━━━"
    if sig.direction == "BUY":
        logic = (f"  • Respected low on 5m identified\n  • Price swept below (stop hunt)\n"
                 f"  • Close back above — trap confirmed\n  • Next bar bullish — entry triggered\n"
                 f"  • TP: Equal highs (30m) at {sig.htf_target:.4f}")
    else:
        logic = (f"  • Respected high on 5m identified\n  • Price swept above (stop hunt)\n"
                 f"  • Close back below — trap confirmed\n  • Next bar bearish — entry triggered\n"
                 f"  • TP: Equal lows (30m) at {sig.htf_target:.4f}")
    return (f"{emoji} <b>[S2] LIQUIDITY SWEEP</b> {arrow}\n<i>Marco Trades — Liquidity Playbook</i>\n{d}\n"
            f"🪙 <b>Symbol   :</b> {sig.symbol}\n📊 <b>Direction:</b> {sig.direction}\n"
            f"⏱ <b>TF       :</b> 5m entry | 30m context\n🕐 <b>Session  :</b> NY Open (13:00–20:00 UTC)\n{d}\n"
            f"🎯 <b>Entry    :</b> {sig.entry:.4f}\n🛑 <b>Stop Loss:</b> {sig.stop_loss:.4f}\n"
            f"✅ <b>Take Profit:</b> {sig.take_profit:.4f}\n📐 <b>R:R      :</b> 1:{sig.rr:.1f}\n{d}\n"
            f"💧 <b>Swept Level :</b> {sig.sweep_price:.4f}\n🏁 <b>HTF Target  :</b> {sig.htf_target:.4f}\n{d}\n"
            f"📋 <b>Setup (Marco's Playbook):</b>\n{logic}\n{d}\n"
            f"⏰ <b>Time (UTC):</b> {sig.timestamp}\n⚠️ <i>Signal only — not financial advice.</i>")

def _analyse(symbol: str, fetch_fn) -> Optional[Signal]:
    if not _in_session(): return None
    raw_ltf = fetch_fn(symbol, LTF, limit=150)
    raw_htf = fetch_fn(symbol, HTF, limit=100)
    if not raw_ltf or not raw_htf:
        log.warning(f"[{symbol}] Data fetch failed."); return None
    ltf = _raw_klines_to_df(raw_ltf)
    htf = _raw_klines_to_df(raw_htf)
    min_bars = SWING_LOOKBACK * 2 + 10
    if len(ltf) < min_bars:
        log.warning(f"[{symbol}] Not enough bars."); return None
    price = ltf["close"].iloc[-1]
    log.info(f"[{symbol}] Close: {price:.4f}")
    resp_highs = [l for l in _mark_respected(ltf, _find_swing_highs(ltf)) if l.respected]
    resp_lows  = [l for l in _mark_respected(ltf, _find_swing_lows(ltf))  if l.respected]

    for level in reversed(resp_highs[-6:]):
        sweep = _detect_sweep(ltf, level)
        if not sweep: continue
        tp = _get_htf_target(htf, "SELL")
        if tp is None or tp >= price: continue
        entry = sweep["entry"]
        # BUG 8 FIX
        stop  = sweep["sweep_price"] * (1 + SWEEP_STOP_BUFFER_PCT / 100)
        rr    = _rr(entry, stop, tp)
        if rr < MIN_RR: continue
        key = f"{symbol}_SELL_{level.bar_index}"
        if _fired.get(symbol) == key: continue
        _fired[symbol] = key
        log.info(f"[{symbol}] ✅ SELL entry={entry:.4f} SL={stop:.4f} TP={tp:.4f} R:R=1:{rr}")
        return Signal(symbol=symbol, direction="SELL", entry=entry, stop_loss=stop,
                      take_profit=tp, rr=rr, sweep_price=sweep["sweep_price"], htf_target=tp,
                      timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"))

    for level in reversed(resp_lows[-6:]):
        sweep = _detect_sweep(ltf, level)
        if not sweep: continue
        tp = _get_htf_target(htf, "BUY")
        if tp is None or tp <= price: continue
        entry = sweep["entry"]
        # BUG 8 FIX
        stop  = sweep["sweep_price"] * (1 - SWEEP_STOP_BUFFER_PCT / 100)
        rr    = _rr(entry, stop, tp)
        if rr < MIN_RR: continue
        key = f"{symbol}_BUY_{level.bar_index}"
        if _fired.get(symbol) == key: continue
        _fired[symbol] = key
        log.info(f"[{symbol}] ✅ BUY  entry={entry:.4f} SL={stop:.4f} TP={tp:.4f} R:R=1:{rr}")
        return Signal(symbol=symbol, direction="BUY", entry=entry, stop_loss=stop,
                      take_profit=tp, rr=rr, sweep_price=sweep["sweep_price"], htf_target=tp,
                      timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"))

    log.info(f"[{symbol}] No valid setup.")
    return None

def run(fetch_klines_fn) -> tuple[list[str], int]:
    messages = []
    if not _in_session():
        h = datetime.now(timezone.utc).hour
        log.info(f"Outside NY session ({h:02d}:xx UTC) — next: {SESSION_START_UTC:02d}:00 UTC")
        return [], POLL_INTERVAL
    log.info(f"── Marco scan {datetime.now(timezone.utc).strftime('%H:%M UTC')} ──")
    for symbol in SYMBOLS:
        try:
            sig = _analyse(symbol, fetch_klines_fn)
            if sig: messages.append(_format_signal(sig))
        except Exception as exc:
            log.error(f"[{symbol}] Error: {exc}", exc_info=True)
    return messages, POLL_INTERVAL
