// PM2 Ecosystem Config — Unified Signal Bot
// Usage: pm2 start ecosystem.config.js
// Logs : /root/unified_bot/logs/

module.exports = {
  apps: [
    {
      name: "unified-bot",
      script: "main.py",
      interpreter: "python3",
      cwd: "/root/unified_bot",
      watch: false,
      autorestart: true,
      restart_delay: 5000,
      max_restarts: 10,
      env: {
        PYTHONUNBUFFERED: "1",
      },
      log_file:   "/root/unified_bot/logs/combined.log",
      out_file:   "/root/unified_bot/logs/out.log",
      error_file: "/root/unified_bot/logs/error.log",
      time: true,
    },
  ],
};
