"""
=============================================================================
Strategy 1 — Marci Silfrain "Little RZY" (Measured Move Trend)
=============================================================================
Symbol    : BTCUSDT
Trend TF  : 4H  — determines direction (up/down/sideways)
Exec TF   : 1H  — detects RZY structure + triggers entry
Scan      : every 15 min | 24/7

Logic:
  1. Confirm trend on 4H via swing-high/low sequence
  2. Wait for strong impulse + pullback on 1H
  3. Fit trendline across pullback highs (short) / lows (long)
  4. Find extreme candle (lowest low / highest high) in pullback
  5. Measure vertical distance: extreme → trendline
  6. Project that distance forward as the target
  7. Entry: price rejects trendline and resumes trend direction
  8. Stop : 0.5% buffer beyond trendline
  9. BB bands for exhaustion context
 10. Warn after 3rd RZY in same trend leg (exhaustion risk)
=============================================================================
"""

import os
import logging
import numpy as np
from datetime import datetime, timezone
from scipy.stats import linregress

log = logging.getLogger("S1-RZY")

# ── Config (tunable via .env) ─────────────────────────────────────────────────
SYMBOL              = "BTCUSDT"
TREND_TF            = "4h"
EXEC_TF             = "1h"
SCAN_INTERVAL       = int(os.getenv("RZY_SCAN_INTERVAL", "900"))   # 15 min
BB_PERIOD           = 20
BB_STD              = 2.0
TREND_LOOKBACK      = 30
SWING_LOOKBACK      = 5
IMPULSE_MIN_PCT     = float(os.getenv("RZY_IMPULSE_MIN_PCT", "0.8"))
PULLBACK_MIN_BAR    = int(os.getenv("RZY_PULLBACK_MIN_BAR", "3"))
PULLBACK_MAX_BAR    = int(os.getenv("RZY_PULLBACK_MAX_BAR", "15"))
RZY_EXHAUSTION_CNT  = int(os.getenv("RZY_EXHAUSTION_COUNT", "3"))

# Dedup — avoid re-sending same signal
_sent_signals: set[str] = set()


# =============================================================================
# INDICATORS
# =============================================================================

def _bollinger_bands(closes: np.ndarray, period: int = 20, std_mult: float = 2.0):
    if len(closes) < period:
        return None, None, None
    sma   = np.mean(closes[-period:])
    sigma = np.std(closes[-period:], ddof=0)
    return sma + std_mult * sigma, sma, sma - std_mult * sigma


def _swing_highs_lows(highs: np.ndarray, lows: np.ndarray, n: int = 5):
    """Returns (swing_highs, swing_lows) as lists of (index, price)."""
    sh, sl = [], []
    length = len(highs)
    for i in range(n, length - n):
        if highs[i] == max(highs[i - n: i + n + 1]):
            sh.append((i, highs[i]))
        if lows[i] == min(lows[i - n: i + n + 1]):
            sl.append((i, lows[i]))
    return sh, sl


def _fit_trendline(xs: np.ndarray, ys: np.ndarray):
    if len(xs) < 2:
        return None, None
    slope, intercept, *_ = linregress(xs, ys)
    return slope, intercept


def _tl_at(slope, intercept, x):
    return slope * x + intercept


# =============================================================================
# TREND DETECTION (4H)
# =============================================================================

def _detect_trend(candles_4h: list[dict]) -> str:
    if len(candles_4h) < TREND_LOOKBACK + SWING_LOOKBACK * 2:
        return "sideways"
    window = candles_4h[-TREND_LOOKBACK:]
    highs  = np.array([c["high"] for c in window])
    lows   = np.array([c["low"]  for c in window])
    sh, sl = _swing_highs_lows(highs, lows, n=SWING_LOOKBACK)
    if len(sh) < 2 or len(sl) < 2:
        return "sideways"
    last_sh = [p for _, p in sh[-3:]]
    last_sl = [p for _, p in sl[-3:]]
    lh = all(last_sh[i] < last_sh[i-1] for i in range(1, len(last_sh)))
    ll = all(last_sl[i] < last_sl[i-1] for i in range(1, len(last_sl)))
    hh = all(last_sh[i] > last_sh[i-1] for i in range(1, len(last_sh)))
    hl = all(last_sl[i] > last_sl[i-1] for i in range(1, len(last_sl)))
    if lh and ll:
        return "downtrend"
    if hh and hl:
        return "uptrend"
    return "sideways"


# =============================================================================
# LITTLE RZY DETECTION (1H)
# =============================================================================

def _find_rzy(candles_1h: list[dict], direction: str) -> dict | None:
    if len(candles_1h) < 40:
        return None

    window  = candles_1h[-60:]
    n       = len(window)
    closes  = np.array([c["close"] for c in window])
    highs   = np.array([c["high"]  for c in window])
    lows    = np.array([c["low"]   for c in window])
    sh, sl  = _swing_highs_lows(highs, lows, n=3)

    if direction == "downtrend":
        if not sl:
            return None
        imp_end_idx, imp_end_low = sl[-1]
        pre_high    = max(highs[max(0, imp_end_idx-10): imp_end_idx+1])
        impulse_pct = (pre_high - imp_end_low) / pre_high * 100
        if impulse_pct < IMPULSE_MIN_PCT:
            return None

        pb_start = imp_end_idx + 1
        pb_end   = min(n - 1, pb_start + PULLBACK_MAX_BAR)
        pb_len   = pb_end - pb_start
        if pb_len < PULLBACK_MIN_BAR:
            return None

        xs   = np.array(range(pb_start, pb_end + 1), dtype=float)
        ys   = highs[pb_start: pb_end + 1]
        slope, intercept = _fit_trendline(xs, ys)
        if slope is None:
            return None

        sub_lows    = lows[pb_start: pb_end + 1]
        ext_idx     = int(np.argmin(sub_lows)) + pb_start
        ext_price   = lows[ext_idx]
        tl_at_ext   = _tl_at(slope, intercept, ext_idx)
        if tl_at_ext <= ext_price:
            return None
        dist = tl_at_ext - ext_price
        if dist / ext_price * 100 < 0.3:
            return None

        target   = ext_price - dist
        tl_now   = _tl_at(slope, intercept, n - 1)
        sl_price = tl_now * 1.005
        tl_curr  = _tl_at(slope, intercept, n - 1)

        if not (closes[-1] < tl_curr and closes[-1] < closes[-2]):
            return None
        for i in [n-1, n-2]:
            if closes[i] > _tl_at(slope, intercept, i):
                return None

        return {
            "direction":    "SHORT",
            "entry":        closes[-1],
            "stop_loss":    sl_price,
            "target":       target,
            "measured_dist": dist,
            "trendline_now": tl_now,
            "impulse_pct":  impulse_pct,
            "pullback_bars": pb_len,
            "extreme_price": ext_price,
        }

    elif direction == "uptrend":
        if not sh:
            return None
        imp_end_idx, imp_end_high = sh[-1]
        pre_low     = min(lows[max(0, imp_end_idx-10): imp_end_idx+1])
        impulse_pct = (imp_end_high - pre_low) / pre_low * 100
        if impulse_pct < IMPULSE_MIN_PCT:
            return None

        pb_start = imp_end_idx + 1
        pb_end   = min(n - 1, pb_start + PULLBACK_MAX_BAR)
        pb_len   = pb_end - pb_start
        if pb_len < PULLBACK_MIN_BAR:
            return None

        xs   = np.array(range(pb_start, pb_end + 1), dtype=float)
        ys   = lows[pb_start: pb_end + 1]
        slope, intercept = _fit_trendline(xs, ys)
        if slope is None:
            return None

        sub_highs  = highs[pb_start: pb_end + 1]
        ext_idx    = int(np.argmax(sub_highs)) + pb_start
        ext_price  = highs[ext_idx]
        tl_at_ext  = _tl_at(slope, intercept, ext_idx)
        if tl_at_ext >= ext_price:
            return None
        dist = ext_price - tl_at_ext
        if dist / ext_price * 100 < 0.3:
            return None

        target   = ext_price + dist
        tl_now   = _tl_at(slope, intercept, n - 1)
        sl_price = tl_now * 0.995
        tl_curr  = _tl_at(slope, intercept, n - 1)

        if not (closes[-1] > tl_curr and closes[-1] > closes[-2]):
            return None
        for i in [n-1, n-2]:
            if closes[i] < _tl_at(slope, intercept, i):
                return None

        return {
            "direction":    "LONG",
            "entry":        closes[-1],
            "stop_loss":    sl_price,
            "target":       target,
            "measured_dist": dist,
            "trendline_now": tl_now,
            "impulse_pct":  impulse_pct,
            "pullback_bars": pb_len,
            "extreme_price": ext_price,
        }

    return None


def _rzy_count(candles_1h: list[dict], direction: str) -> int:
    window = candles_1h[-60:]
    highs  = np.array([c["high"] for c in window])
    lows   = np.array([c["low"]  for c in window])
    sh, sl = _swing_highs_lows(highs, lows, n=3)
    return len(sl) if direction == "downtrend" else len(sh)


def _bb_context(candles_1h: list[dict], direction: str) -> str:
    closes = np.array([c["close"] for c in candles_1h])
    upper, mid, lower = _bollinger_bands(closes, BB_PERIOD, BB_STD)
    if upper is None:
        return "BB: N/A"
    price = closes[-1]
    pct_b = (price - lower) / (upper - lower) * 100 if (upper - lower) != 0 else 50
    if direction == "downtrend":
        quality = (
            "✅ High-prob (near upper BB)"     if pct_b > 80 else
            "⚠️ Mid zone (moderate)"           if pct_b > 50 else
            "❌ Near lower BB (exhaustion risk)"
        )
    else:
        quality = (
            "✅ High-prob (near lower BB)"     if pct_b < 20 else
            "⚠️ Mid zone (moderate)"           if pct_b < 50 else
            "❌ Near upper BB (exhaustion risk)"
        )
    return (
        f"Upper: ${upper:,.0f} | Mid: ${mid:,.0f} | Lower: ${lower:,.0f}\n"
        f"%B: {pct_b:.1f}% → {quality}"
    )


# =============================================================================
# TELEGRAM MESSAGE
# =============================================================================

def _build_message(setup: dict, trend: str, bb_ctx: str, rzy_cnt: int) -> str:
    d         = setup["direction"]
    entry     = setup["entry"]
    sl        = setup["stop_loss"]
    target    = setup["target"]
    dist      = setup["measured_dist"]
    impulse   = setup["impulse_pct"]
    pb_bars   = setup["pullback_bars"]
    risk      = abs(entry - sl)
    reward    = abs(target - entry)
    rr        = reward / risk if risk > 0 else 0
    emoji     = "🔴 SHORT ↓" if d == "SHORT" else "🟢 LONG ↑"
    ts        = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    exhaustion_warn = ""
    if rzy_cnt >= RZY_EXHAUSTION_CNT:
        exhaustion_warn = (
            f"\n⚠️ <b>EXHAUSTION WARNING</b>: {rzy_cnt} RZY structures in this "
            f"trend leg. Lower-probability — trade with caution or skip."
        )
    return (
        f"━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📐 <b>[S1] LITTLE RZY</b> — {emoji}\n"
        f"<i>Marci Silfrain — Measured Move Trend</i>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🕐 {ts}\n"
        f"🪙 <b>Symbol</b>: {SYMBOL} | Binance Futures\n"
        f"⏱ <b>TF</b>: 4H trend + 1H structure\n"
        f"📊 <b>4H Trend</b>: {trend.upper()} | <b>Direction</b>: {d}\n\n"
        f"💰 <b>TRADE LEVELS</b>\n"
        f"  Entry  : <b>${entry:,.2f}</b>\n"
        f"  Target : <b>${target:,.2f}</b>  ({abs(target-entry)/entry*100:.2f}%)\n"
        f"  Stop   : <b>${sl:,.2f}</b>       ({abs(sl-entry)/entry*100:.2f}%)\n"
        f"  R:R    : <b>{rr:.1f}:1</b>\n\n"
        f"📏 <b>MEASURED MOVE</b>\n"
        f"  Impulse   : {impulse:.2f}%\n"
        f"  Pullback  : {pb_bars} candles (1H)\n"
        f"  Distance  : ${dist:,.2f}\n\n"
        f"📈 <b>BOLLINGER BANDS (1H, 20/2)</b>\n"
        f"{bb_ctx}\n\n"
        f"🔢 <b>RZY count in leg</b>: {rzy_cnt} "
        f"{'(fresh ✅)' if rzy_cnt <= 2 else '(maturing ⚠️)'}"
        f"{exhaustion_warn}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"⚠️ <i>Signal only — not financial advice.</i>"
    )


# =============================================================================
# PUBLIC ENTRY POINT
# =============================================================================

def run(fetch_klines_fn) -> tuple[str | None, int]:
    """
    Called by main.py every SCAN_INTERVAL seconds.
    Returns (message_or_None, sleep_seconds).
    """
    log.info(f"Scanning {SYMBOL} ...")

    c4h = fetch_klines_fn(SYMBOL, TREND_TF,  limit=100)
    c1h = fetch_klines_fn(SYMBOL, EXEC_TF,   limit=100)

    if not c4h or not c1h:
        log.warning("Fetch failed. Skipping.")
        return None, SCAN_INTERVAL

    c4h = c4h[:-1]  # drop unclosed candle
    c1h = c1h[:-1]

    trend = _detect_trend(c4h)
    log.info(f"4H trend: {trend}")

    if trend == "sideways":
        log.info("Sideways — no RZY setup.")
        return None, SCAN_INTERVAL

    setup = _find_rzy(c1h, trend)
    if setup is None:
        log.info(f"No RZY setup found ({trend}).")
        return None, SCAN_INTERVAL

    log.info(f"Setup found: {setup['direction']} @ {setup['entry']:.2f}")

    sig_key = f"{setup['direction']}_{round(setup['entry'], -1)}"
    if sig_key in _sent_signals:
        log.info(f"Already sent (key={sig_key}). Skipping.")
        return None, SCAN_INTERVAL

    bb_ctx  = _bb_context(c1h, trend)
    rzy_cnt = _rzy_count(c1h, trend)
    msg     = _build_message(setup, trend, bb_ctx, rzy_cnt)

    _sent_signals.add(sig_key)
    if len(_sent_signals) > 50:
        _sent_signals.clear()

    return msg, SCAN_INTERVAL
