"""
=============================================================================
Strategy 3 — Trader Mayne "Structure & OTE" (MSB + OB + Breaker)
=============================================================================
Symbols  : XAUUSDT, BTCUSDT
HTF      : 1D  — trend, MSB, range, Order Block / POI
LTF      : 30m — OTE zone entry, breaker confirmation
Scan     : every 5 min | 24/7

5 Sequential Gates — ALL must pass:
  Gate 1 — HTF MSB     : Clean Market Structure Break on Daily
  Gate 2 — HTF Range   : Mark range, identify 50% midpoint
  Gate 3 — POI/OB      : Last up/down candle before MSB impulse
  Gate 4 — OTE Zone    : Price in OB + correct half (discount/premium)
  Gate 5 — LTF Breaker : 30m swing swept + MSB opposite direction
=============================================================================
"""

import os
import logging
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd

log = logging.getLogger("S3-MAYNE")

# ── Config ────────────────────────────────────────────────────────────────────
SYMBOLS             = ["XAUUSDT", "BTCUSDT"]
HTF                 = "1d"
LTF                 = "30m"
SWING_LOOKBACK      = int(float(os.getenv("TM_SWING_LOOKBACK",   "10")))
OB_LOOKBACK         = int(float(os.getenv("TM_OB_LOOKBACK",      "5")))
SWEEP_BUFFER_PCT    = float(os.getenv("TM_SWEEP_BUFFER_PCT",     "0.05"))
OB_ZONE_BUFFER_PCT  = float(os.getenv("TM_OB_ZONE_BUFFER_PCT",  "0.20"))
MIN_RR              = float(os.getenv("TM_MIN_RR",               "2.0"))
POLL_INTERVAL       = int(float(os.getenv("TM_POLL_INTERVAL",    "300")))

_fired: dict[str, str] = {}


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class MSBResult:
    direction:    str
    msb_price:    float
    msb_bar:      int
    swing_origin: float
    swing_end:    float
    midpoint:     float
    ob_high:      float
    ob_low:       float
    ob_bar:       int
    ext_target:   float


@dataclass
class LTFConfirmation:
    swept_price: float
    entry:       float
    stop_loss:   float


@dataclass
class Signal:
    symbol:      str
    direction:   str
    entry:       float
    stop_loss:   float
    take_profit: float
    rr:          float
    msb_price:   float
    ob_high:     float
    ob_low:      float
    midpoint:    float
    swept_price: float
    ext_target:  float
    timestamp:   str


# =============================================================================
# HELPERS
# =============================================================================

def _raw_to_df(raw: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(raw)
    df = df.iloc[:-1].copy()
    df.rename(columns={"ts": "open_time", "vol": "volume"}, inplace=True)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df.set_index("open_time", inplace=True)
    return df[["open", "high", "low", "close", "volume"]]


def _swing_highs(df: pd.DataFrame, lookback: int) -> list[tuple[int, float]]:
    highs, out = df["high"].values, []
    for i in range(lookback, len(df) - 1):
        if highs[i] >= max(highs[i - lookback: i + 1]):
            out.append((i, highs[i]))
    return out


def _swing_lows(df: pd.DataFrame, lookback: int) -> list[tuple[int, float]]:
    lows, out = df["low"].values, []
    for i in range(lookback, len(df) - 1):
        if lows[i] <= min(lows[i - lookback: i + 1]):
            out.append((i, lows[i]))
    return out


def _calc_rr(entry: float, stop: float, tp: float) -> float:
    risk   = abs(entry - stop)
    reward = abs(tp - entry)
    return round(reward / risk, 2) if risk > 0 else 0.0


# =============================================================================
# GATE 1 — HTF MARKET STRUCTURE BREAK
# =============================================================================

def _detect_msb(htf_df: pd.DataFrame) -> Optional[MSBResult]:
    closes = htf_df["close"].values
    highs  = htf_df["high"].values
    lows   = htf_df["low"].values
    opens  = htf_df["open"].values
    n      = len(htf_df)

    sh_list = _swing_highs(htf_df, SWING_LOOKBACK)
    sl_list = _swing_lows(htf_df,  SWING_LOOKBACK)
    search_start = max(SWING_LOOKBACK + 5, n - 30)
    best: Optional[MSBResult] = None

    for i in range(search_start, n):
        body_pct = abs(closes[i] - opens[i]) / max(opens[i], 1e-9) * 100

        # ── Bullish MSB ──────────────────────────────────────────────────
        broken_sh = [sh for sh in sh_list if sh[0] < i - 2 and sh[1] < closes[i]]
        if broken_sh and body_pct > 0.3:
            sh_bar, sh_price = broken_sh[-1]
            sl_before = [sl for sl in sl_list if sl[0] < sh_bar]
            if not sl_before:
                continue
            sl_bar, sl_price = sl_before[-1]
            midpoint = (sh_price + sl_price) / 2
            ob_bar = next(
                (j for j in range(sh_bar, max(sh_bar - OB_LOOKBACK, sl_bar), -1)
                 if closes[j] < opens[j]),
                sh_bar - 1
            )
            ob_bar   = max(ob_bar, 0)
            future_sh = [sh for sh in sh_list if sh[0] > i and sh[1] > closes[i]]
            ext_target = future_sh[0][1] if future_sh else sh_price * 1.02
            best = MSBResult(
                direction="bullish", msb_price=sh_price, msb_bar=i,
                swing_origin=sl_price, swing_end=sh_price, midpoint=midpoint,
                ob_high=highs[ob_bar], ob_low=lows[ob_bar], ob_bar=ob_bar,
                ext_target=ext_target,
            )

        # ── Bearish MSB ──────────────────────────────────────────────────
        broken_sl = [sl for sl in sl_list if sl[0] < i - 2 and sl[1] > closes[i]]
        if broken_sl and body_pct > 0.3:
            sl_bar, sl_price = broken_sl[-1]
            sh_before = [sh for sh in sh_list if sh[0] < sl_bar]
            if not sh_before:
                continue
            sh_bar, sh_price = sh_before[-1]
            midpoint = (sh_price + sl_price) / 2
            ob_bar = next(
                (j for j in range(sl_bar, max(sl_bar - OB_LOOKBACK, sh_bar), -1)
                 if closes[j] > opens[j]),
                sl_bar - 1
            )
            ob_bar    = max(ob_bar, 0)
            future_sl = [sl for sl in sl_list if sl[0] > i and sl[1] < closes[i]]
            ext_target = future_sl[0][1] if future_sl else sl_price * 0.98
            best = MSBResult(
                direction="bearish", msb_price=sl_price, msb_bar=i,
                swing_origin=sh_price, swing_end=sl_price, midpoint=midpoint,
                ob_high=highs[ob_bar], ob_low=lows[ob_bar], ob_bar=ob_bar,
                ext_target=ext_target,
            )

    return best


# =============================================================================
# GATE 2+3+4 — PRICE IN OTE ZONE + INSIDE ORDER BLOCK
# =============================================================================

def _price_in_ote_and_ob(price: float, msb: MSBResult) -> bool:
    in_discount = price < msb.midpoint
    in_premium  = price > msb.midpoint
    in_ob       = msb.ob_low <= price <= msb.ob_high
    if msb.direction == "bullish":
        return in_discount and in_ob
    return in_premium and in_ob


# =============================================================================
# GATE 5 — LTF BREAKER / LIQUIDITY GRAB (30m)
# =============================================================================

def _detect_ltf_breaker(ltf_df: pd.DataFrame, msb: MSBResult) -> Optional[LTFConfirmation]:
    highs  = ltf_df["high"].values
    lows   = ltf_df["low"].values
    closes = ltf_df["close"].values
    n      = len(ltf_df)
    buf    = closes[-1] * SWEEP_BUFFER_PCT / 100
    scan_start = max(SWING_LOOKBACK + 3, n - 30)

    if msb.direction == "bullish":
        ltf_sl = _swing_lows(ltf_df, 3)
        recent_sl = [(i, p) for (i, p) in ltf_sl if i >= scan_start]
        for sl_bar, sl_price in reversed(recent_sl):
            for i in range(sl_bar + 1, n - 1):
                if lows[i] < sl_price - buf and closes[i] > sl_price:
                    ltf_sh = _swing_highs(ltf_df, 3)
                    sh_before = [(j, p) for (j, p) in ltf_sh if sl_bar <= j < i]
                    if not sh_before:
                        continue
                    _, ltf_sh_price = sh_before[-1]
                    for k in range(i + 1, min(i + 6, n)):
                        if closes[k] > ltf_sh_price:
                            return LTFConfirmation(
                                swept_price=lows[i],
                                entry=closes[k],
                                stop_loss=lows[i] * 0.999,
                            )
    else:
        ltf_sh = _swing_highs(ltf_df, 3)
        recent_sh = [(i, p) for (i, p) in ltf_sh if i >= scan_start]
        for sh_bar, sh_price in reversed(recent_sh):
            for i in range(sh_bar + 1, n - 1):
                if highs[i] > sh_price + buf and closes[i] < sh_price:
                    ltf_sl = _swing_lows(ltf_df, 3)
                    sl_before = [(j, p) for (j, p) in ltf_sl if sh_bar <= j < i]
                    if not sl_before:
                        continue
                    _, ltf_sl_price = sl_before[-1]
                    for k in range(i + 1, min(i + 6, n)):
                        if closes[k] < ltf_sl_price:
                            return LTFConfirmation(
                                swept_price=highs[i],
                                entry=closes[k],
                                stop_loss=highs[i] * 1.001,
                            )
    return None


# =============================================================================
# TELEGRAM MESSAGE
# =============================================================================

def _format_signal(sig: Signal) -> str:
    emoji = "🟢" if sig.direction == "BUY" else "🔴"
    arrow = "📈" if sig.direction == "BUY" else "📉"
    d     = "━━━━━━━━━━━━━━━━━━━━━"
    zone  = "DISCOUNT (below 50%)" if sig.direction == "BUY" else "PREMIUM (above 50%)"
    ob_lbl = "Bullish OB" if sig.direction == "BUY" else "Bearish OB"
    if sig.direction == "BUY":
        logic = (
            "  1️⃣ Bullish MSB confirmed on Daily chart\n"
            f"  2️⃣ Range midpoint: {sig.midpoint:.4f} — DISCOUNT zone\n"
            f"  3️⃣ Bullish OB: {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
            "  4️⃣ Price pulled into OB inside discount zone\n"
            "  5️⃣ 30m: Swing low swept → MSB up → Breaker entry\n"
            f"  🎯 Target: Next HTF swing high at {sig.ext_target:.4f}"
        )
    else:
        logic = (
            "  1️⃣ Bearish MSB confirmed on Daily chart\n"
            f"  2️⃣ Range midpoint: {sig.midpoint:.4f} — PREMIUM zone\n"
            f"  3️⃣ Bearish OB: {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
            "  4️⃣ Price pulled into OB inside premium zone\n"
            "  5️⃣ 30m: Swing high swept → MSB down → Breaker entry\n"
            f"  🎯 Target: Next HTF swing low at {sig.ext_target:.4f}"
        )
    return (
        f"{emoji} <b>[S3] STRUCTURE &amp; OTE</b> {arrow}\n"
        f"<i>Trader Mayne — MSB → OB → Breaker</i>\n"
        f"{d}\n"
        f"🪙 <b>Symbol   :</b> {sig.symbol}\n"
        f"📊 <b>Direction:</b> {sig.direction}\n"
        f"⏱ <b>TF       :</b> 1D HTF | 30m LTF\n"
        f"📍 <b>OTE Zone :</b> {zone}\n"
        f"{d}\n"
        f"🎯 <b>Entry    :</b> {sig.entry:.4f}\n"
        f"🛑 <b>Stop Loss:</b> {sig.stop_loss:.4f}\n"
        f"✅ <b>Take Profit:</b> {sig.take_profit:.4f}\n"
        f"📐 <b>R:R      :</b> 1:{sig.rr:.1f}\n"
        f"{d}\n"
        f"🔱 <b>HTF MSB Level :</b> {sig.msb_price:.4f}\n"
        f"📦 <b>{ob_lbl} Zone  :</b> {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
        f"💧 <b>LTF Swept Level:</b> {sig.swept_price:.4f}\n"
        f"🏁 <b>HTF Target     :</b> {sig.ext_target:.4f}\n"
        f"{d}\n"
        f"📋 <b>Setup Gates (Trader Mayne):</b>\n{logic}\n"
        f"{d}\n"
        f"⏰ <b>Time (UTC):</b> {sig.timestamp}\n"
        f"⚠️ <i>Signal only — not financial advice. DYOR.</i>"
    )


# =============================================================================
# PER-SYMBOL ANALYSIS
# =============================================================================

def _analyse(symbol: str, fetch_fn) -> Optional[Signal]:
    log.info(f"[{symbol}] Scanning ...")

    raw_htf = fetch_fn(symbol, HTF, limit=120)
    raw_ltf = fetch_fn(symbol, LTF, limit=100)

    if not raw_htf or not raw_ltf:
        log.warning(f"[{symbol}] Data fetch failed.")
        return None

    htf_df = _raw_to_df(raw_htf)
    ltf_df = _raw_to_df(raw_ltf)

    if len(htf_df) < SWING_LOOKBACK + 15 or len(ltf_df) < SWING_LOOKBACK + 10:
        log.warning(f"[{symbol}] Insufficient bars.")
        return None

    current_price = ltf_df["close"].iloc[-1]
    log.info(f"[{symbol}] Price: {current_price:.4f}")

    # Gate 1
    msb = _detect_msb(htf_df)
    if msb is None:
        log.info(f"[{symbol}] GATE 1 ✗ — No Daily MSB.")
        return None
    log.info(f"[{symbol}] GATE 1 ✓ — {msb.direction.upper()} MSB @ {msb.msb_price:.4f}")

    # Gate 2+3+4
    if not _price_in_ote_and_ob(current_price, msb):
        log.info(f"[{symbol}] GATE 2-4 ✗ — Price not in OB/OTE zone.")
        return None
    log.info(f"[{symbol}] GATE 2-4 ✓ — Price inside OB + OTE zone.")

    # Gate 5
    confirm = _detect_ltf_breaker(ltf_df, msb)
    if confirm is None:
        log.info(f"[{symbol}] GATE 5 ✗ — No LTF breaker confirmed.")
        return None
    log.info(f"[{symbol}] GATE 5 ✓ — Breaker: swept={confirm.swept_price:.4f} entry={confirm.entry:.4f}")

    direction = "BUY" if msb.direction == "bullish" else "SELL"
    rr        = _calc_rr(confirm.entry, confirm.stop_loss, msb.ext_target)

    if rr < MIN_RR:
        log.info(f"[{symbol}] R:R {rr:.1f} < min {MIN_RR} — skipped.")
        return None

    key = f"{symbol}_{direction}_{msb.msb_bar}_{msb.ob_bar}"
    if _fired.get(symbol) == key:
        log.debug(f"[{symbol}] Already fired this signal.")
        return None
    _fired[symbol] = key

    log.info(f"[{symbol}] ✅ {direction} entry={confirm.entry:.4f} SL={confirm.stop_loss:.4f} TP={msb.ext_target:.4f} R:R=1:{rr}")
    return Signal(
        symbol=symbol, direction=direction,
        entry=confirm.entry, stop_loss=confirm.stop_loss,
        take_profit=msb.ext_target, rr=rr,
        msb_price=msb.msb_price,
        ob_high=msb.ob_high, ob_low=msb.ob_low,
        midpoint=msb.midpoint,
        swept_price=confirm.swept_price,
        ext_target=msb.ext_target,
        timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    )


# =============================================================================
# PUBLIC ENTRY POINT
# =============================================================================

def run(fetch_klines_fn) -> tuple[list[str], int]:
    """
    Called by main.py every POLL_INTERVAL seconds.
    Returns (list_of_messages, sleep_seconds).
    """
    messages = []
    log.info(f"── Mayne scan cycle {datetime.now(timezone.utc).strftime('%H:%M UTC')} ──")

    for symbol in SYMBOLS:
        try:
            sig = _analyse(symbol, fetch_klines_fn)
            if sig:
                messages.append(_format_signal(sig))
        except Exception as exc:
            log.error(f"[{symbol}] Error: {exc}", exc_info=True)

    return messages, POLL_INTERVAL
