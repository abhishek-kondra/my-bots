"""
=============================================================================
UNIFIED SIGNAL BOT — 3 Strategies, 1 Process, 1 Telegram Channel
=============================================================================
Memory-optimised version:
  - Strategies imported lazily (only when first scan runs)
  - Threads staggered 20s apart to avoid simultaneous pandas load
  - gc.collect() called after each scan to release unused memory
  - Candle limit reduced to 120 (was 200) — sufficient for all strategies
=============================================================================
"""

import os
import gc
import time
import logging
import threading
import requests
from datetime import datetime, timezone
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN  = os.getenv("TELEGRAM_BOT_TOKEN",  "")
TELEGRAM_CHAT_ID    = os.getenv("TELEGRAM_CHAT_ID",    "")
TELEGRAM_CHAT_ID_2  = os.getenv("TELEGRAM_CHAT_ID_2",  "743777930")
BINANCE_BASE       = "https://fapi.binance.com"

# ── Logging ───────────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/unified_bot.log"),
    ],
)
log = logging.getLogger("main")

# Strategies are NOT imported at module level — loaded lazily on first scan
_strategies_loaded = False
_strategies_lock   = threading.Lock()
marci_rzy        = None
marco_liquidity  = None
trader_mayne     = None


def _load_strategies():
    """Import all strategy modules once, on first scan. Lazy load saves ~60MB at startup."""
    global _strategies_loaded, marci_rzy, marco_liquidity, trader_mayne
    with _strategies_lock:
        if _strategies_loaded:
            return
        log.info("Loading strategy modules (first scan) ...")
        from strategies import marci_rzy as _s1
        from strategies import marco_liquidity as _s2
        from strategies import trader_mayne as _s3
        marci_rzy       = _s1
        marco_liquidity = _s2
        trader_mayne    = _s3
        _strategies_loaded = True
        log.info("Strategy modules loaded.")


# =============================================================================
# SHARED BINANCE FETCHER — reduced limit to 120 candles (was 200)
# =============================================================================

def fetch_klines(symbol: str, interval: str, limit: int = 120) -> list[dict]:
    url    = f"{BINANCE_BASE}/fapi/v1/klines"
    params = {"symbol": symbol, "interval": interval, "limit": min(limit, 120)}
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = [
            {
                "ts":    r[0],
                "open":  float(r[1]),
                "high":  float(r[2]),
                "low":   float(r[3]),
                "close": float(r[4]),
                "vol":   float(r[5]),
            }
            for r in resp.json()
        ]
        return data
    except Exception as exc:
        log.error(f"fetch_klines({symbol},{interval}): {exc}")
        return []


def check_binance() -> bool:
    try:
        r = requests.get(f"{BINANCE_BASE}/fapi/v1/ping", timeout=5)
        r.raise_for_status()
        log.info("✅ Binance Futures API reachable.")
        return True
    except Exception as e:
        log.error(f"❌ Binance Futures API unreachable: {e}")
        return False


# =============================================================================
# TELEGRAM — thread-safe sender
# =============================================================================

_tg_lock = threading.Lock()


def send_telegram(message: str) -> bool:
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        log.warning("Telegram credentials not set — skipping send.")
        return False
    url      = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    chat_ids = [TELEGRAM_CHAT_ID]
    if TELEGRAM_CHAT_ID_2:
        chat_ids.append(TELEGRAM_CHAT_ID_2)
    success = True
    with _tg_lock:
        for cid in chat_ids:
            data = {
                "chat_id":    cid,
                "text":       message,
                "parse_mode": "HTML",
            }
            try:
                resp = requests.post(url, data=data, timeout=10)
                resp.raise_for_status()
                log.info(f"✉️  Telegram sent to {cid}.")
            except Exception as exc:
                log.error(f"Telegram send error (chat_id={cid}): {exc}")
                success = False
    return success


# =============================================================================
# STRATEGY THREADS — staggered start, gc after each scan
# =============================================================================

def run_strategy_1():
    """Marci Silfrain — Little RZY — every 15 min."""
    log.info("[S1-RZY] Thread started.")
    sleep_sec = 900
    while True:
        try:
            _load_strategies()
            msg, sleep_sec = marci_rzy.run(fetch_klines)
            if msg:
                send_telegram(msg)
        except Exception as exc:
            log.error(f"[S1-RZY] Error: {exc}", exc_info=True)
            sleep_sec = 900
        finally:
            gc.collect()   # release memory after scan
        log.info(f"[S1-RZY] Next scan in {sleep_sec}s.")
        time.sleep(sleep_sec)


def run_strategy_2():
    """Marco Trades — Liquidity Sweep — every 60s, session-gated."""
    log.info("[S2-MARCO] Thread started.")
    sleep_sec = 60
    while True:
        try:
            _load_strategies()
            msgs, sleep_sec = marco_liquidity.run(fetch_klines)
            for msg in msgs:
                send_telegram(msg)
                time.sleep(1)
        except Exception as exc:
            log.error(f"[S2-MARCO] Error: {exc}", exc_info=True)
            sleep_sec = 60
        finally:
            gc.collect()
        log.info(f"[S2-MARCO] Next scan in {sleep_sec}s.")
        time.sleep(sleep_sec)


def run_strategy_3():
    """Trader Mayne — Structure & OTE — every 5 min."""
    log.info("[S3-MAYNE] Thread started.")
    sleep_sec = 300
    while True:
        try:
            _load_strategies()
            msgs, sleep_sec = trader_mayne.run(fetch_klines)
            for msg in msgs:
                send_telegram(msg)
                time.sleep(1)
        except Exception as exc:
            log.error(f"[S3-MAYNE] Error: {exc}", exc_info=True)
            sleep_sec = 300
        finally:
            gc.collect()
        log.info(f"[S3-MAYNE] Next scan in {sleep_sec}s.")
        time.sleep(sleep_sec)


# =============================================================================
# STARTUP BANNER
# =============================================================================

def send_startup_message():
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    msg = (
        "🤖 <b>UNIFIED SIGNAL BOT — ONLINE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🕐 Started : {now}\n"
        f"📡 Data    : Binance Futures (public, no API key)\n\n"
        "📐 <b>Strategy 1 — Little RZY</b>\n"
        "  Marci Silfrain | BTCUSDT\n"
        "  4H trend + 1H execution | Scan: 15 min | 24/7\n\n"
        "💧 <b>Strategy 2 — Liquidity Sweep</b>\n"
        "  Marco Trades | XAUUSDT + BTCUSDT\n"
        "  30m context + 5m entry | Scan: 1 min | NY Open 13–20 UTC\n\n"
        "🔱 <b>Strategy 3 — Structure &amp; OTE</b>\n"
        "  Trader Mayne | XAUUSDT + BTCUSDT\n"
        "  1D HTF + 30m LTF | Scan: 5 min | 24/7\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "⚠️ <i>Signals only — not financial advice.</i>"
    )
    send_telegram(msg)


# =============================================================================
# ENTRY POINT
# =============================================================================

def main():
    log.info("=" * 65)
    log.info("  UNIFIED SIGNAL BOT — Memory-Optimised Build")
    log.info("  S1: Marci RZY       (BTCUSDT,  4H/1H,  15min)")
    log.info("  S2: Marco Sweep     (XAU+BTC,  30m/5m,  1min, NY session)")
    log.info("  S3: Mayne OTE       (XAU+BTC,  1D/30m,  5min)")
    log.info("=" * 65)

    if not check_binance():
        log.error("Cannot reach Binance Futures API.")
        return

    send_startup_message()

    # Stagger thread starts 20s apart — prevents simultaneous pandas load spike
    thread_configs = [
        (run_strategy_1, "S1-RZY",   0),
        (run_strategy_2, "S2-MARCO", 20),
        (run_strategy_3, "S3-MAYNE", 40),
    ]

    threads = []
    for target, name, delay in thread_configs:
        if delay > 0:
            log.info(f"Waiting {delay}s before starting {name} ...")
            time.sleep(delay)
        t = threading.Thread(target=target, name=name, daemon=True)
        t.start()
        threads.append(t)
        log.info(f"✅ Started thread: {name}")

    # Heartbeat every 30 min
    try:
        while True:
            time.sleep(1800)
            alive = [t.name for t in threads if t.is_alive()]
            dead  = [t.name for t in threads if not t.is_alive()]
            log.info(f"💓 Heartbeat — alive: {alive}" + (f" | DEAD: {dead}" if dead else ""))
            if dead:
                send_telegram(
                    f"⚠️ <b>UNIFIED BOT — THREAD DIED</b>\n"
                    f"Dead: {dead} | Alive: {alive}\n"
                    f"Time: {datetime.now(timezone.utc).strftime('%H:%M UTC')}\n"
                    "Restart: <code>pm2 restart unified-bot</code>"
                )
    except KeyboardInterrupt:
        log.info("Shutdown requested. Exiting.")


if __name__ == "__main__":
    main()
