"""
Trader Mayne — Structure & OTE Playbook Bot
============================================
Data source : Binance Futures public REST (fapi.binance.com) — no API keys needed
Symbols     : XAUUSDT, BTCUSDT
Timeframes  : HTF 1D (trend / MSB / POI) | LTF 30m (OTE zone / breaker entry)
Style       : Swing Trading

Strategy — 5 sequential gates (ALL must pass):

  GATE 1 — HTF TREND & MSB
    Detect a clean Market Structure Break on the Daily chart.
    Bullish MSB = price breaks above a prior significant swing high.
    Bearish MSB = price breaks below a prior significant swing low.

  GATE 2 — HTF RANGE & OTE ZONE
    Mark the range from the swing that caused the MSB.
    50% midpoint separates discount (lower half) from premium (upper half).
    Bullish bias → only enter in the DISCOUNT zone (below 50%).
    Bearish bias → only enter in the PREMIUM zone (above 50%).

  GATE 3 — POINT OF INTEREST (POI)
    Identify the Order Block (OB) that caused the MSB move.
    Bullish OB = the last bearish (down) candle before the bullish impulse.
    Bearish OB = the last bullish (up) candle before the bearish impulse.
    Price must retrace INTO this OB zone.

  GATE 4 — PRICE INSIDE POI + OTE ZONE
    Price on the LTF must currently be inside both:
      - The HTF Order Block zone
      - The correct OTE half of the range (discount for longs, premium for shorts)

  GATE 5 — LTF BREAKER / LIQUIDITY GRAB CONFIRMATION
    Inside the POI on the 30m chart:
      - A swing high/low forms (engineered liquidity).
      - That level gets swept (stop run).
      - Price breaks market structure in the opposite direction (breaker setup).
    Entry on the retest / close after the MSB on LTF.

  Stop-loss  : Below the swept low (longs) / above swept high (shorts)
  Target     : Next HTF external liquidity — previous swing high (longs) / swing low (shorts)
  Min R:R    : 2.0
"""

import os
import time
import logging
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd
import requests
from dotenv import load_dotenv

load_dotenv()

# ─────────────────────────────────────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("logs/trader_mayne_bot.log"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class Config:
    # Telegram
    telegram_token:   str = field(default_factory=lambda: os.getenv("TELEGRAM_BOT_TOKEN", ""))
    telegram_chat_id: str = field(default_factory=lambda: os.getenv("TELEGRAM_CHAT_ID", ""))
    telegram_chat_id_2: str = field(default_factory=lambda: os.getenv("TELEGRAM_CHAT_ID_2", "743777930"))

    # Binance Futures public REST
    base_url: str = "https://fapi.binance.com"

    # Symbols
    symbols: list = field(default_factory=lambda: ["XAUUSDT", "BTCUSDT"])

    # Timeframes
    htf: str = "1d"    # Daily  — trend, MSB, range, OB/POI
    ltf: str = "30m"   # 30-min — OTE entry, breaker confirmation

    # Strategy parameters (tunable via .env)
    swing_lookback:     int   = int(float(os.getenv("TM_SWING_LOOKBACK",   "10")))
    ob_lookback:        int   = int(float(os.getenv("TM_OB_LOOKBACK",      "5")))   # candles before MSB impulse to find OB
    sweep_buffer_pct:   float = float(os.getenv("TM_SWEEP_BUFFER_PCT",    "0.05"))  # % beyond level for sweep
    ob_zone_buffer_pct: float = float(os.getenv("TM_OB_ZONE_BUFFER_PCT",  "0.20"))  # OB zone width (% of OB candle range)
    min_rr:             float = float(os.getenv("TM_MIN_RR",              "2.0"))
    poll_interval:      int   = int(float(os.getenv("TM_POLL_INTERVAL",   "300")))  # 5 min — swing style


cfg = Config()


# ─────────────────────────────────────────────────────────────────────────────
# DATA STRUCTURES
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class MSBResult:
    direction:    str    # "bullish" | "bearish"
    msb_price:    float  # the level that was broken
    msb_bar:      int    # bar index of the break
    swing_origin: float  # start of the range (swing low for bull, swing high for bear)
    swing_end:    float  # end of the range (swing high for bull, swing low for bear)
    midpoint:     float  # 50% of the range
    ob_high:      float  # Order Block zone top
    ob_low:       float  # Order Block zone bottom
    ob_bar:       int    # bar index of the OB candle
    ext_target:   float  # next HTF external liquidity target


@dataclass
class LTFConfirmation:
    swept_price:  float  # the wick extreme of the liquidity grab
    entry:        float  # entry price (close after breaker MSB)
    stop_loss:    float  # below swept low (long) / above swept high (short)


@dataclass
class Signal:
    symbol:      str
    direction:   str    # "BUY" | "SELL"
    entry:       float
    stop_loss:   float
    take_profit: float
    rr:          float
    # Context
    msb_price:   float
    ob_high:     float
    ob_low:      float
    midpoint:    float
    swept_price: float
    ext_target:  float
    timestamp:   str


# ─────────────────────────────────────────────────────────────────────────────
# BINANCE FUTURES — PUBLIC DATA FETCHER
# ─────────────────────────────────────────────────────────────────────────────
def fetch_klines(symbol: str, interval: str, limit: int = 200) -> Optional[pd.DataFrame]:
    url    = f"{cfg.base_url}/fapi/v1/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        raw = resp.json()
        df = pd.DataFrame(raw, columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_volume", "trades",
            "taker_buy_base", "taker_buy_quote", "ignore",
        ])
        df = df.iloc[:-1].copy()   # drop unclosed candle
        df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
        df.set_index("open_time", inplace=True)
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = df[col].astype(float)
        log.debug(f"[{symbol}] {interval} — {len(df)} closed candles")
        return df[["open", "high", "low", "close", "volume"]]
    except requests.RequestException as e:
        log.error(f"[{symbol}] Fetch error ({interval}): {e}")
        return None


# ─────────────────────────────────────────────────────────────────────────────
# TELEGRAM
# ─────────────────────────────────────────────────────────────────────────────
def send_telegram(text: str) -> bool:
    if not cfg.telegram_token or not cfg.telegram_chat_id:
        log.warning("Telegram credentials not set — skipping send.")
        return False
    url      = f"https://api.telegram.org/bot{cfg.telegram_token}/sendMessage"
    chat_ids = [cfg.telegram_chat_id]
    if cfg.telegram_chat_id_2:
        chat_ids.append(cfg.telegram_chat_id_2)
    success = True
    for cid in chat_ids:
        try:
            r = requests.post(url, json={
                "chat_id": cid,
                "text": text,
                "parse_mode": "HTML",
            }, timeout=10)
            r.raise_for_status()
            log.info(f"✉️  Telegram sent to {cid}.")
        except Exception as e:
            log.error(f"Telegram send failed (chat_id={cid}): {e}")
            success = False
    return success
    url = f"https://api.telegram.org/bot{cfg.telegram_token}/sendMessage"
    try:
        r = requests.post(url, json={
            "chat_id": cfg.telegram_chat_id,
            "text": text,
            "parse_mode": "HTML",
        }, timeout=10)
        r.raise_for_status()
        log.info("✉️  Telegram sent.")
        return True
    except Exception as e:
        log.error(f"Telegram error: {e}")
        return False


def format_signal(sig: Signal) -> str:
    emoji  = "🟢" if sig.direction == "BUY" else "🔴"
    arrow  = "📈" if sig.direction == "BUY" else "📉"
    d      = "━━━━━━━━━━━━━━━━━━━━━"
    zone   = "DISCOUNT (below 50%)" if sig.direction == "BUY" else "PREMIUM (above 50%)"
    ob_lbl = "Bullish OB" if sig.direction == "BUY" else "Bearish OB"

    if sig.direction == "BUY":
        logic = (
            "  1️⃣ Bullish MSB confirmed on Daily chart\n"
            f"  2️⃣ Range 50% midpoint: {sig.midpoint:.4f} — in DISCOUNT zone\n"
            f"  3️⃣ Bullish Order Block: {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
            "  4️⃣ Price pulled into OB inside discount zone\n"
            "  5️⃣ 30m: Swing low swept → MSB up → Breaker entry\n"
            f"  🎯 Target: Next HTF swing high at {sig.ext_target:.4f}"
        )
    else:
        logic = (
            "  1️⃣ Bearish MSB confirmed on Daily chart\n"
            f"  2️⃣ Range 50% midpoint: {sig.midpoint:.4f} — in PREMIUM zone\n"
            f"  3️⃣ Bearish Order Block: {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
            "  4️⃣ Price pulled into OB inside premium zone\n"
            "  5️⃣ 30m: Swing high swept → MSB down → Breaker entry\n"
            f"  🎯 Target: Next HTF swing low at {sig.ext_target:.4f}"
        )

    return (
        f"{emoji} <b>STRUCTURE &amp; OTE SIGNAL</b> {arrow}\n"
        f"<i>Trader Mayne's Playbook</i>\n"
        f"{d}\n"
        f"🪙 <b>Symbol :</b> {sig.symbol}\n"
        f"📊 <b>Direction :</b> {sig.direction}\n"
        f"⏱ <b>Timeframes :</b> 1D HTF | 30m LTF\n"
        f"📍 <b>OTE Zone :</b> {zone}\n"
        f"{d}\n"
        f"🎯 <b>Entry :</b> {sig.entry:.4f}\n"
        f"🛑 <b>Stop Loss :</b> {sig.stop_loss:.4f}\n"
        f"✅ <b>Take Profit :</b> {sig.take_profit:.4f}\n"
        f"📐 <b>R:R :</b> 1:{sig.rr:.1f}\n"
        f"{d}\n"
        f"🔱 <b>HTF MSB Level :</b> {sig.msb_price:.4f}\n"
        f"📦 <b>{ob_lbl} Zone :</b> {sig.ob_low:.4f} – {sig.ob_high:.4f}\n"
        f"💧 <b>LTF Swept Level :</b> {sig.swept_price:.4f}\n"
        f"🏁 <b>HTF Target :</b> {sig.ext_target:.4f}\n"
        f"{d}\n"
        f"📋 <b>Setup Gates (Trader Mayne):</b>\n{logic}\n"
        f"{d}\n"
        f"⏰ <b>Time (UTC) :</b> {sig.timestamp}\n"
        f"⚠️ <i>Signal only — not financial advice. DYOR.</i>"
    )


# ─────────────────────────────────────────────────────────────────────────────
# GATE 1 — HTF MARKET STRUCTURE BREAK (MSB)
# ─────────────────────────────────────────────────────────────────────────────
def _swing_highs(df: pd.DataFrame, lookback: int) -> list[tuple[int, float]]:
    highs = df["high"].values
    out   = []
    for i in range(lookback, len(df) - 1):
        if highs[i] >= max(highs[i - lookback: i + 1]):
            out.append((i, highs[i]))
    return out


def _swing_lows(df: pd.DataFrame, lookback: int) -> list[tuple[int, float]]:
    lows = df["low"].values
    out  = []
    for i in range(lookback, len(df) - 1):
        if lows[i] <= min(lows[i - lookback: i + 1]):
            out.append((i, lows[i]))
    return out


def detect_msb(htf_df: pd.DataFrame) -> Optional[MSBResult]:
    """
    Scan the Daily chart for the most recent clean MSB.

    Bullish MSB: current close > a prior significant swing high
    Bearish MSB: current close < a prior significant swing low

    We look at the last N bars and find the most recent valid break.
    The break candle must have a clear impulse (body > 0.3% of price).
    """
    closes = htf_df["close"].values
    highs  = htf_df["high"].values
    lows   = htf_df["low"].values
    opens  = htf_df["open"].values
    n      = len(htf_df)

    sh_list = _swing_highs(htf_df, cfg.swing_lookback)
    sl_list = _swing_lows(htf_df, cfg.swing_lookback)

    # Search last 30 bars for an MSB
    search_start = max(cfg.swing_lookback + 5, n - 30)

    best: Optional[MSBResult] = None

    for i in range(search_start, n):
        body_pct = abs(closes[i] - opens[i]) / opens[i] * 100

        # ── Bullish MSB ──────────────────────────────────────────────────
        # Find the most recent swing high before bar i that gets broken
        broken_sh = [sh for sh in sh_list if sh[0] < i - 2 and sh[1] < closes[i]]
        if broken_sh and body_pct > 0.3:
            sh_bar, sh_price = broken_sh[-1]   # most recent broken swing high

            # Range: from swing low just before the swing high → swing high
            sl_before_sh = [sl for sl in sl_list if sl[0] < sh_bar]
            if not sl_before_sh:
                continue
            sl_bar, sl_price = sl_before_sh[-1]

            midpoint  = (sh_price + sl_price) / 2
            range_h   = sh_price
            range_l   = sl_price

            # Order Block: last bearish (down) candle before the bullish impulse that broke sh
            # Look back from sh_bar for the last down candle
            ob_bar = None
            for j in range(sh_bar, max(sh_bar - cfg.ob_lookback, sl_bar), -1):
                if closes[j] < opens[j]:   # bearish candle
                    ob_bar = j
                    break
            if ob_bar is None:
                ob_bar = sh_bar - 1

            ob_body_range = abs(highs[ob_bar] - lows[ob_bar])
            ob_high = highs[ob_bar]
            ob_low  = lows[ob_bar]

            # External liquidity target: next swing high above current price
            future_sh = [sh for sh in sh_list if sh[0] > i and sh[1] > closes[i]]
            if future_sh:
                ext_target = future_sh[0][1]
            else:
                # Use the swing high that was broken + some projection
                ext_target = sh_price * 1.02

            best = MSBResult(
                direction="bullish",
                msb_price=sh_price,
                msb_bar=i,
                swing_origin=sl_price,
                swing_end=sh_price,
                midpoint=midpoint,
                ob_high=ob_high,
                ob_low=ob_low,
                ob_bar=ob_bar,
                ext_target=ext_target,
            )

        # ── Bearish MSB ──────────────────────────────────────────────────
        broken_sl = [sl for sl in sl_list if sl[0] < i - 2 and sl[1] > closes[i]]
        if broken_sl and body_pct > 0.3:
            sl_bar, sl_price = broken_sl[-1]

            sh_before_sl = [sh for sh in sh_list if sh[0] < sl_bar]
            if not sh_before_sl:
                continue
            sh_bar, sh_price = sh_before_sl[-1]

            midpoint = (sh_price + sl_price) / 2

            # Order Block: last bullish (up) candle before the bearish impulse that broke sl
            ob_bar = None
            for j in range(sl_bar, max(sl_bar - cfg.ob_lookback, sh_bar), -1):
                if closes[j] > opens[j]:   # bullish candle
                    ob_bar = j
                    break
            if ob_bar is None:
                ob_bar = sl_bar - 1

            ob_high = highs[ob_bar]
            ob_low  = lows[ob_bar]

            # External liquidity target: next swing low below current price
            future_sl = [sl for sl in sl_list if sl[0] > i and sl[1] < closes[i]]
            if future_sl:
                ext_target = future_sl[0][1]
            else:
                ext_target = sl_price * 0.98

            best = MSBResult(
                direction="bearish",
                msb_price=sl_price,
                msb_bar=i,
                swing_origin=sh_price,
                swing_end=sl_price,
                midpoint=midpoint,
                ob_high=ob_high,
                ob_low=ob_low,
                ob_bar=ob_bar,
                ext_target=ext_target,
            )

    return best   # most recent MSB found (or None)


# ─────────────────────────────────────────────────────────────────────────────
# GATE 2+3+4 — PRICE IN OTE ZONE + INSIDE POI (ORDER BLOCK)
# ─────────────────────────────────────────────────────────────────────────────
def price_in_ote_and_ob(current_price: float, msb: MSBResult) -> bool:
    """
    Check that price is:
      - In the correct OTE half (discount for bull, premium for bear)
      - Inside the HTF Order Block zone
    """
    in_discount = current_price < msb.midpoint   # below 50% = discount
    in_premium  = current_price > msb.midpoint   # above 50% = premium

    in_ob = msb.ob_low <= current_price <= msb.ob_high

    if msb.direction == "bullish":
        return in_discount and in_ob
    else:
        return in_premium and in_ob


# ─────────────────────────────────────────────────────────────────────────────
# GATE 5 — LTF BREAKER CONFIRMATION (30m)
# ─────────────────────────────────────────────────────────────────────────────
def detect_ltf_breaker(ltf_df: pd.DataFrame, msb: MSBResult) -> Optional[LTFConfirmation]:
    """
    Inside the OB zone on the 30m chart:

    For BUY:
      - A swing low forms (engineered liquidity)
      - That swing low gets swept (price wicks below it, closes back above)
      - Price then breaks structure to the upside (MSB up on LTF)
      → Entry on the close of the candle that broke structure

    For SELL:
      - A swing high forms inside the OB
      - That high gets swept
      - Price breaks structure downward
      → Entry on the close of the break candle
    """
    highs  = ltf_df["high"].values
    lows   = ltf_df["low"].values
    closes = ltf_df["close"].values
    opens  = ltf_df["open"].values
    n      = len(ltf_df)
    buf    = closes[-1] * cfg.sweep_buffer_pct / 100

    # Only scan last 30 bars (setup must be recent)
    scan_start = max(cfg.swing_lookback + 3, n - 30)

    if msb.direction == "bullish":
        # Find a swing low → sweep → MSB up
        ltf_sl = _swing_lows(ltf_df, 3)   # use shorter lookback for LTF precision
        recent_sl = [(i, p) for (i, p) in ltf_sl if i >= scan_start]

        for sl_bar, sl_price in reversed(recent_sl):
            # Look for a sweep of this low
            for i in range(sl_bar + 1, n - 1):
                swept  = lows[i] < sl_price - buf
                rejects = closes[i] > sl_price   # closes back above
                if swept and rejects:
                    # Now look for an MSB up (close above a recent LTF high)
                    ltf_sh = _swing_highs(ltf_df, 3)
                    sh_before_sweep = [(j, p) for (j, p) in ltf_sh if sl_bar <= j < i]
                    if not sh_before_sweep:
                        continue
                    _, ltf_sh_price = sh_before_sweep[-1]

                    for k in range(i + 1, min(i + 6, n)):
                        if closes[k] > ltf_sh_price:
                            # Confirmed breaker — entry on this close
                            entry    = closes[k]
                            stop     = lows[i] * 0.999   # just below swept wick
                            return LTFConfirmation(
                                swept_price=lows[i],
                                entry=entry,
                                stop_loss=stop,
                            )

    else:  # bearish
        ltf_sh = _swing_highs(ltf_df, 3)
        recent_sh = [(i, p) for (i, p) in ltf_sh if i >= scan_start]

        for sh_bar, sh_price in reversed(recent_sh):
            for i in range(sh_bar + 1, n - 1):
                swept   = highs[i] > sh_price + buf
                rejects = closes[i] < sh_price
                if swept and rejects:
                    ltf_sl = _swing_lows(ltf_df, 3)
                    sl_before_sweep = [(j, p) for (j, p) in ltf_sl if sh_bar <= j < i]
                    if not sl_before_sweep:
                        continue
                    _, ltf_sl_price = sl_before_sweep[-1]

                    for k in range(i + 1, min(i + 6, n)):
                        if closes[k] < ltf_sl_price:
                            entry = closes[k]
                            stop  = highs[i] * 1.001
                            return LTFConfirmation(
                                swept_price=highs[i],
                                entry=entry,
                                stop_loss=stop,
                            )

    return None


# ─────────────────────────────────────────────────────────────────────────────
# R:R CALCULATOR
# ─────────────────────────────────────────────────────────────────────────────
def calc_rr(entry: float, stop: float, tp: float) -> float:
    risk   = abs(entry - stop)
    reward = abs(tp - entry)
    return round(reward / risk, 2) if risk > 0 else 0.0


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ANALYSIS ENGINE
# ─────────────────────────────────────────────────────────────────────────────
_fired: dict[str, str] = {}   # dedup: symbol → last signal key


def analyse(symbol: str) -> Optional[Signal]:
    log.info(f"[{symbol}] ── Scanning ──")

    # ── Fetch candles ────────────────────────────────────────────────────
    htf_df = fetch_klines(symbol, cfg.htf, limit=120)
    ltf_df = fetch_klines(symbol, cfg.ltf, limit=100)

    if htf_df is None or ltf_df is None:
        log.warning(f"[{symbol}] Data fetch failed.")
        return None
    if len(htf_df) < cfg.swing_lookback + 15 or len(ltf_df) < cfg.swing_lookback + 10:
        log.warning(f"[{symbol}] Insufficient bars.")
        return None

    current_price = ltf_df["close"].iloc[-1]
    log.info(f"[{symbol}] Price: {current_price:.4f}")

    # ── GATE 1: HTF MSB ──────────────────────────────────────────────────
    msb = detect_msb(htf_df)
    if msb is None:
        log.info(f"[{symbol}] GATE 1 ✗ — No clear MSB on Daily.")
        return None
    log.info(f"[{symbol}] GATE 1 ✓ — {msb.direction.upper()} MSB at {msb.msb_price:.4f}")

    # ── GATE 2+3+4: Price in OTE zone & inside OB ────────────────────────
    if not price_in_ote_and_ob(current_price, msb):
        zone = "discount" if msb.direction == "bullish" else "premium"
        log.info(
            f"[{symbol}] GATE 2-4 ✗ — Price {current_price:.4f} not in OB "
            f"({msb.ob_low:.4f}–{msb.ob_high:.4f}) / {zone} zone (mid={msb.midpoint:.4f})."
        )
        return None
    log.info(
        f"[{symbol}] GATE 2-4 ✓ — Price in OB zone & OTE "
        f"({'discount' if msb.direction == 'bullish' else 'premium'})."
    )

    # ── GATE 5: LTF breaker / liquidity grab confirmation ────────────────
    confirm = detect_ltf_breaker(ltf_df, msb)
    if confirm is None:
        log.info(f"[{symbol}] GATE 5 ✗ — No LTF breaker confirmation yet.")
        return None
    log.info(
        f"[{symbol}] GATE 5 ✓ — Breaker confirmed. "
        f"Swept: {confirm.swept_price:.4f} | Entry: {confirm.entry:.4f}"
    )

    # ── R:R check ────────────────────────────────────────────────────────
    direction = "BUY" if msb.direction == "bullish" else "SELL"
    rr = calc_rr(confirm.entry, confirm.stop_loss, msb.ext_target)

    if rr < cfg.min_rr:
        log.info(f"[{symbol}] R:R {rr:.1f} < min {cfg.min_rr} — skipped.")
        return None

    # ── Dedup ────────────────────────────────────────────────────────────
    key = f"{symbol}_{direction}_{msb.msb_bar}_{msb.ob_bar}"
    if _fired.get(symbol) == key:
        log.debug(f"[{symbol}] Already fired this signal — skip.")
        return None
    _fired[symbol] = key

    log.info(
        f"[{symbol}] ✅ {direction} | Entry {confirm.entry:.4f} "
        f"SL {confirm.stop_loss:.4f} TP {msb.ext_target:.4f} R:R 1:{rr}"
    )

    return Signal(
        symbol=symbol,
        direction=direction,
        entry=confirm.entry,
        stop_loss=confirm.stop_loss,
        take_profit=msb.ext_target,
        rr=rr,
        msb_price=msb.msb_price,
        ob_high=msb.ob_high,
        ob_low=msb.ob_low,
        midpoint=msb.midpoint,
        swept_price=confirm.swept_price,
        ext_target=msb.ext_target,
        timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    )


# ─────────────────────────────────────────────────────────────────────────────
# CONNECTIVITY CHECK
# ─────────────────────────────────────────────────────────────────────────────
def check_binance() -> bool:
    try:
        r = requests.get(f"{cfg.base_url}/fapi/v1/ping", timeout=5)
        r.raise_for_status()
        log.info("✅ Binance Futures API reachable.")
        return True
    except Exception as e:
        log.error(f"❌ Binance Futures API unreachable: {e}")
        return False


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
def main():
    log.info("=" * 62)
    log.info("  Trader Mayne — Structure & OTE Playbook Bot")
    log.info(f"  Data       : Binance Futures (fapi.binance.com) — public")
    log.info(f"  Symbols    : {cfg.symbols}")
    log.info(f"  Timeframes : HTF {cfg.htf} | LTF {cfg.ltf}")
    log.info(f"  Min R:R    : {cfg.min_rr}")
    log.info(f"  Poll every : {cfg.poll_interval}s")
    log.info("=" * 62)

    if not check_binance():
        log.error("Exiting — cannot reach Binance Futures API.")
        return

    send_telegram(
        "🤖 <b>Trader Mayne Structure &amp; OTE Bot — Online</b>\n"
        "📖 <i>Strategy: MSB → Range → POI → OTE → LTF Breaker</i>\n"
        f"📡 Source: Binance Futures (public, no keys)\n"
        f"🪙 Symbols: {' | '.join(cfg.symbols)}\n"
        f"⏱ HTF: {cfg.htf} | LTF: {cfg.ltf}\n"
        f"📐 Min R:R: {cfg.min_rr}\n"
        f"🔄 Polling every {cfg.poll_interval}s"
    )

    cycle = 0
    while True:
        cycle += 1
        cycle_start = time.time()
        now = datetime.now(timezone.utc).strftime("%H:%M UTC")
        log.info(f"═══ Cycle #{cycle} — {now} ═══")

        for symbol in cfg.symbols:
            try:
                sig = analyse(symbol)
                if sig:
                    send_telegram(format_signal(sig))
            except Exception as e:
                log.error(f"[{symbol}] Unhandled error: {e}", exc_info=True)

        elapsed    = time.time() - cycle_start
        sleep_time = max(0, cfg.poll_interval - elapsed)
        log.info(f"Cycle done in {elapsed:.1f}s — next scan in {sleep_time:.0f}s")
        time.sleep(sleep_time)


if __name__ == "__main__":
    main()
