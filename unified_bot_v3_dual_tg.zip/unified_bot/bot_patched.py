"""
Marco Trades — Liquidity Playbook Bot
======================================
Data source : Binance Futures public REST (fapi.binance.com) — no API keys needed
Symbols     : XAUUSDT, BTCUSDT
Timeframes  : HTF 30m (context / TP targets) | LTF 5m (entry / sweep detection)
Session     : NY Open 13:00–20:00 UTC  (per Marco's playbook)
Signals     : Telegram

Strategy logic
  1. Find swing highs/lows on LTF that were RESPECTED (price moved away)
  2. Wait for a LIQUIDITY SWEEP  — price wicks beyond the level then closes back
  3. CONFIRM the trap — next bar continues the reversal
  4. HTF equal highs/lows are used as the take-profit target
  5. Only fire if R:R >= MIN_RR
"""

import os
import time
import logging
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd
import requests
from dotenv import load_dotenv

load_dotenv()

# ─────────────────────────────────────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("logs/bot.log"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# CONFIG  (edit .env — nothing hardcoded except strategy defaults)
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class Config:
    # Telegram
    telegram_token:  str = field(default_factory=lambda: os.getenv("TELEGRAM_BOT_TOKEN", ""))
    telegram_chat_id: str = field(default_factory=lambda: os.getenv("TELEGRAM_CHAT_ID", ""))
    telegram_chat_id_2: str = field(default_factory=lambda: os.getenv("TELEGRAM_CHAT_ID_2", "743777930"))

    # Binance Futures public REST — no auth needed
    base_url: str = "https://fapi.binance.com"

    # Symbols in Binance Futures format
    symbols: list = field(default_factory=lambda: ["XAUUSDT", "BTCUSDT"])

    # Timeframes (Binance interval strings)
    htf: str = "30m"   # context + TP target detection
    ltf: str = "5m"    # sweep detection + entry

    # Session window — NY Open per Marco's playbook
    session_start_utc: int = 13   # 13:00 UTC
    session_end_utc:   int = 20   # 20:00 UTC

    # Strategy parameters (tunable via .env)
    swing_lookback:        int   = int(float(os.getenv("SWING_LOOKBACK",    "10")))
    sweep_buffer_pct:      float = float(os.getenv("SWEEP_BUFFER_PCT",      "0.05"))
    equal_hl_tolerance_pct: float = float(os.getenv("EQUAL_HL_TOL_PCT",    "0.10"))
    confirmation_bars:     int   = int(float(os.getenv("CONFIRM_BARS",      "3")))
    min_rr:                float = float(os.getenv("MIN_RR",                "2.0"))

    # How many seconds between full scan cycles
    poll_interval: int = int(float(os.getenv("POLL_INTERVAL", "60")))


cfg = Config()


# ─────────────────────────────────────────────────────────────────────────────
# DATA STRUCTURES
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class SwingLevel:
    price:         float
    bar_index:     int
    level_type:    str    # "high" | "low"
    respected:     bool = False   # price moved away after this level formed
    equal_cluster: bool = False   # part of an equal-highs / equal-lows cluster


@dataclass
class Signal:
    symbol:      str
    direction:   str    # "BUY" | "SELL"
    entry:       float
    stop_loss:   float
    take_profit: float
    rr:          float
    sweep_price: float  # the wick extreme that ran the level
    htf_target:  float  # equal H/L on 30m used as TP
    timestamp:   str


# ─────────────────────────────────────────────────────────────────────────────
# BINANCE FUTURES — PUBLIC DATA FETCHER
# ─────────────────────────────────────────────────────────────────────────────
def fetch_klines(symbol: str, interval: str, limit: int = 200) -> Optional[pd.DataFrame]:
    """
    Fetch OHLCV from Binance Futures public endpoint.
    No API key required.
    Returns a DataFrame indexed by UTC timestamp.
    """
    url = f"{cfg.base_url}/fapi/v1/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        raw = resp.json()
        df = pd.DataFrame(raw, columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_volume", "trades",
            "taker_buy_base", "taker_buy_quote", "ignore",
        ])
        # Drop the still-open (current) candle — it hasn't closed yet
        df = df.iloc[:-1].copy()

        df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
        df.set_index("open_time", inplace=True)
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = df[col].astype(float)

        log.debug(f"[{symbol}] {interval} — fetched {len(df)} closed candles")
        return df[["open", "high", "low", "close", "volume"]]
    except requests.RequestException as e:
        log.error(f"[{symbol}] Binance fetch error ({interval}): {e}")
        return None


# ─────────────────────────────────────────────────────────────────────────────
# TELEGRAM
# ─────────────────────────────────────────────────────────────────────────────
def send_telegram(text: str) -> bool:
    if not cfg.telegram_token or not cfg.telegram_chat_id:
        log.warning("Telegram credentials not set — skipping send.")
        return False
    url      = f"https://api.telegram.org/bot{cfg.telegram_token}/sendMessage"
    chat_ids = [cfg.telegram_chat_id]
    if cfg.telegram_chat_id_2:
        chat_ids.append(cfg.telegram_chat_id_2)
    success = True
    for cid in chat_ids:
        try:
            r = requests.post(url, json={
                "chat_id": cid,
                "text": text,
                "parse_mode": "HTML",
            }, timeout=10)
            r.raise_for_status()
            log.info(f"✉️  Telegram sent to {cid}.")
        except Exception as e:
            log.error(f"Telegram send failed (chat_id={cid}): {e}")
            success = False
    return success


def format_signal(sig: Signal) -> str:
    emoji   = "🟢" if sig.direction == "BUY" else "🔴"
    arrow   = "📈" if sig.direction == "BUY" else "📉"
    divider = "━━━━━━━━━━━━━━━━━━━━━"

    if sig.direction == "BUY":
        logic = (
            "  • Respected low on 5m identified\n"
            "  • Price swept below the low (stop hunt)\n"
            "  • Close back above — trap confirmed\n"
            "  • Next bar continued bullish — entry triggered\n"
            f"  • TP: Equal highs (30m) at {sig.htf_target:.4f}"
        )
    else:
        logic = (
            "  • Respected high on 5m identified\n"
            "  • Price swept above the high (stop hunt)\n"
            "  • Close back below — trap confirmed\n"
            "  • Next bar continued bearish — entry triggered\n"
            f"  • TP: Equal lows (30m) at {sig.htf_target:.4f}"
        )

    return (
        f"{emoji} <b>LIQUIDITY SWEEP SIGNAL</b> {arrow}\n"
        f"{divider}\n"
        f"🪙 <b>Symbol :</b> {sig.symbol}\n"
        f"📊 <b>Direction :</b> {sig.direction}\n"
        f"⏱ <b>Timeframes :</b> 5m entry | 30m context\n"
        f"🕐 <b>Session :</b> NY Open (13:00–20:00 UTC)\n"
        f"{divider}\n"
        f"🎯 <b>Entry :</b> {sig.entry:.4f}\n"
        f"🛑 <b>Stop Loss :</b> {sig.stop_loss:.4f}\n"
        f"✅ <b>Take Profit :</b> {sig.take_profit:.4f}\n"
        f"📐 <b>R:R :</b> 1:{sig.rr:.1f}\n"
        f"{divider}\n"
        f"💧 <b>Swept Level :</b> {sig.sweep_price:.4f}\n"
        f"🏁 <b>HTF Target :</b> {sig.htf_target:.4f}\n"
        f"{divider}\n"
        f"📋 <b>Setup (Marco's Playbook):</b>\n{logic}\n"
        f"{divider}\n"
        f"⏰ <b>Time (UTC) :</b> {sig.timestamp}\n"
        f"⚠️ <i>Signal only — not financial advice. DYOR.</i>"
    )


# ─────────────────────────────────────────────────────────────────────────────
# STRATEGY HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def _find_swing_highs(df: pd.DataFrame, lookback: int) -> list[SwingLevel]:
    highs = df["high"].values
    result = []
    for i in range(lookback, len(df) - 1):
        window = highs[i - lookback: i + 1]
        if highs[i] >= max(window):
            result.append(SwingLevel(price=highs[i], bar_index=i, level_type="high"))
    return result


def _find_swing_lows(df: pd.DataFrame, lookback: int) -> list[SwingLevel]:
    lows = df["low"].values
    result = []
    for i in range(lookback, len(df) - 1):
        window = lows[i - lookback: i + 1]
        if lows[i] <= min(window):
            result.append(SwingLevel(price=lows[i], bar_index=i, level_type="low"))
    return result


def _mark_respected(df: pd.DataFrame, levels: list[SwingLevel]) -> list[SwingLevel]:
    """
    A level is respected when the next 5 bars move meaningfully away from it.
    This means stops/orders were resting there — it has liquidity.
    """
    closes = df["close"].values
    for lvl in levels:
        future = closes[lvl.bar_index + 1: lvl.bar_index + 6]
        if len(future) < 2:
            continue
        move_pct = abs(future[-1] - lvl.price) / lvl.price * 100
        if lvl.level_type == "high" and future[-1] < lvl.price and move_pct > 0.05:
            lvl.respected = True
        elif lvl.level_type == "low" and future[-1] > lvl.price and move_pct > 0.05:
            lvl.respected = True
    return levels


def _mark_equal_clusters(levels: list[SwingLevel], tol_pct: float) -> list[SwingLevel]:
    """
    Mark levels that cluster tightly together — these are 'equal highs/lows',
    the strongest resting liquidity targets per Marco's playbook.
    """
    prices = [l.price for l in levels]
    for lvl in levels:
        siblings = [
            p for p in prices
            if p != lvl.price and abs(p - lvl.price) / lvl.price * 100 <= tol_pct
        ]
        if siblings:
            lvl.equal_cluster = True
    return levels


def _detect_sweep(df: pd.DataFrame, level: SwingLevel) -> Optional[dict]:
    """
    Scan recent bars for a sweep of `level`:
      HIGH sweep → wick above level, close back below, next bar lower
      LOW  sweep → wick below level, close back above, next bar higher

    Returns dict with sweep metadata or None.
    """
    highs  = df["high"].values
    lows   = df["low"].values
    closes = df["close"].values
    n      = len(df)
    buf    = level.price * cfg.sweep_buffer_pct / 100

    # Only search recent bars — sweeps that already happened 20+ bars ago are stale
    search_from = max(level.bar_index + 1, n - 15)

    for i in range(search_from, n - 1):
        if level.level_type == "high":
            swept   = highs[i] > level.price + buf
            rejects = closes[i] < level.price
            confirm = closes[i + 1] < closes[i]
            if swept and rejects and confirm:
                return {
                    "bar":         i,
                    "sweep_price": highs[i],
                    "entry":       closes[i + 1],
                }
        else:  # low
            swept   = lows[i] < level.price - buf
            rejects = closes[i] > level.price
            confirm = closes[i + 1] > closes[i]
            if swept and rejects and confirm:
                return {
                    "bar":         i,
                    "sweep_price": lows[i],
                    "entry":       closes[i + 1],
                }
    return None


def _get_htf_target(htf_df: pd.DataFrame, direction: str) -> Optional[float]:
    """
    Marco's playbook: TP = equal highs (BUY) or equal lows (SELL) on the 30m chart.
    Falls back to the nearest respected level if no equal cluster is found.
    """
    current = htf_df["close"].iloc[-1]

    if direction == "BUY":
        levels = _find_swing_highs(htf_df, cfg.swing_lookback)
        levels = _mark_respected(htf_df, levels)
        levels = _mark_equal_clusters(levels, cfg.equal_hl_tolerance_pct)
        candidates = [l for l in levels if l.respected and l.price > current]
        # Prefer equal-cluster levels (strongest liquidity)
        eq = [l for l in candidates if l.equal_cluster]
        pool = eq if eq else candidates
        return min(pool, key=lambda l: l.price).price if pool else None

    else:  # SELL
        levels = _find_swing_lows(htf_df, cfg.swing_lookback)
        levels = _mark_respected(htf_df, levels)
        levels = _mark_equal_clusters(levels, cfg.equal_hl_tolerance_pct)
        candidates = [l for l in levels if l.respected and l.price < current]
        eq = [l for l in candidates if l.equal_cluster]
        pool = eq if eq else candidates
        return max(pool, key=lambda l: l.price).price if pool else None


def _rr(entry: float, stop: float, tp: float) -> float:
    risk   = abs(entry - stop)
    reward = abs(tp - entry)
    return round(reward / risk, 2) if risk > 0 else 0.0


def _in_session() -> bool:
    h = datetime.now(timezone.utc).hour
    return cfg.session_start_utc <= h < cfg.session_end_utc


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ANALYSIS  — called every poll cycle per symbol
# ─────────────────────────────────────────────────────────────────────────────

# Dedup: remember the last signal key fired per symbol
_fired: dict[str, str] = {}


def analyse(symbol: str) -> Optional[Signal]:
    # ── 1. Session gate ──────────────────────────────────────────────────
    if not _in_session():
        log.debug(f"[{symbol}] Outside NY session — skipping.")
        return None

    # ── 2. Fetch candles ─────────────────────────────────────────────────
    ltf = fetch_klines(symbol, cfg.ltf, limit=150)
    htf = fetch_klines(symbol, cfg.htf, limit=100)

    if ltf is None or htf is None or len(ltf) < cfg.swing_lookback + 10:
        log.warning(f"[{symbol}] Not enough data.")
        return None

    price = ltf["close"].iloc[-1]
    log.info(f"[{symbol}] Last close: {price:.4f} | LTF bars: {len(ltf)}")

    # ── 3. Build respected LTF swing levels ──────────────────────────────
    resp_highs = [l for l in _mark_respected(ltf, _find_swing_highs(ltf, cfg.swing_lookback)) if l.respected]
    resp_lows  = [l for l in _mark_respected(ltf, _find_swing_lows(ltf,  cfg.swing_lookback)) if l.respected]

    # ── 4. Scan for SELL setup (sweep of a respected high) ───────────────
    for level in reversed(resp_highs[-6:]):
        sweep = _detect_sweep(ltf, level)
        if not sweep:
            continue

        tp = _get_htf_target(htf, "SELL")
        if tp is None or tp >= price:
            continue

        entry = sweep["entry"]
        stop  = sweep["sweep_price"] * 1.0015   # small buffer above wick
        rr    = _rr(entry, stop, tp)

        if rr < cfg.min_rr:
            log.info(f"[{symbol}] SELL candidate — R:R {rr:.1f} below min {cfg.min_rr} — skip.")
            continue

        key = f"{symbol}_SELL_{level.bar_index}"
        if _fired.get(symbol) == key:
            log.debug(f"[{symbol}] SELL already fired for this level — skip.")
            continue
        _fired[symbol] = key

        log.info(f"[{symbol}] ✅ SELL  entry={entry:.4f}  SL={stop:.4f}  TP={tp:.4f}  R:R=1:{rr}")
        return Signal(
            symbol=symbol, direction="SELL",
            entry=entry, stop_loss=stop, take_profit=tp, rr=rr,
            sweep_price=sweep["sweep_price"], htf_target=tp,
            timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        )

    # ── 5. Scan for BUY setup (sweep of a respected low) ─────────────────
    for level in reversed(resp_lows[-6:]):
        sweep = _detect_sweep(ltf, level)
        if not sweep:
            continue

        tp = _get_htf_target(htf, "BUY")
        if tp is None or tp <= price:
            continue

        entry = sweep["entry"]
        stop  = sweep["sweep_price"] * 0.9985   # small buffer below wick
        rr    = _rr(entry, stop, tp)

        if rr < cfg.min_rr:
            log.info(f"[{symbol}] BUY candidate — R:R {rr:.1f} below min {cfg.min_rr} — skip.")
            continue

        key = f"{symbol}_BUY_{level.bar_index}"
        if _fired.get(symbol) == key:
            log.debug(f"[{symbol}] BUY already fired for this level — skip.")
            continue
        _fired[symbol] = key

        log.info(f"[{symbol}] ✅ BUY   entry={entry:.4f}  SL={stop:.4f}  TP={tp:.4f}  R:R=1:{rr}")
        return Signal(
            symbol=symbol, direction="BUY",
            entry=entry, stop_loss=stop, take_profit=tp, rr=rr,
            sweep_price=sweep["sweep_price"], htf_target=tp,
            timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        )

    log.info(f"[{symbol}] No valid setup this cycle.")
    return None


# ─────────────────────────────────────────────────────────────────────────────
# BOOT CHECK — verify Binance connectivity at startup
# ─────────────────────────────────────────────────────────────────────────────
def check_binance_connectivity() -> bool:
    try:
        r = requests.get(f"{cfg.base_url}/fapi/v1/ping", timeout=5)
        r.raise_for_status()
        log.info("✅ Binance Futures API reachable.")
        return True
    except Exception as e:
        log.error(f"❌ Binance Futures API unreachable: {e}")
        return False


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
def main():
    log.info("=" * 60)
    log.info("  Marco Trades — Liquidity Playbook Bot")
    log.info(f"  Data       : Binance Futures (fapi.binance.com) — public")
    log.info(f"  Symbols    : {cfg.symbols}")
    log.info(f"  Timeframes : HTF {cfg.htf} | LTF {cfg.ltf}")
    log.info(f"  Session    : NY Open {cfg.session_start_utc:02d}:00–{cfg.session_end_utc:02d}:00 UTC")
    log.info(f"  Min R:R    : {cfg.min_rr}")
    log.info(f"  Poll every : {cfg.poll_interval}s")
    log.info("=" * 60)

    if not check_binance_connectivity():
        log.error("Exiting — cannot reach Binance Futures API.")
        return

    send_telegram(
        "🤖 <b>Marco Liquidity Bot — Online</b>\n"
        f"📡 Source: Binance Futures (public, no keys)\n"
        f"🪙 Symbols: {' | '.join(cfg.symbols)}\n"
        f"⏱ HTF: {cfg.htf} | LTF: {cfg.ltf}\n"
        f"🕐 Session: NY Open 13:00–20:00 UTC\n"
        f"📐 Min R:R: {cfg.min_rr}"
    )

    while True:
        cycle_start = time.time()
        now_utc = datetime.now(timezone.utc)

        if _in_session():
            log.info(f"─── Scan cycle {now_utc.strftime('%H:%M UTC')} ───")
            for symbol in cfg.symbols:
                try:
                    sig = analyse(symbol)
                    if sig:
                        send_telegram(format_signal(sig))
                except Exception as e:
                    log.error(f"[{symbol}] Unexpected error: {e}", exc_info=True)
        else:
            log.info(
                f"Outside session ({now_utc.strftime('%H:%M UTC')}) — "
                f"next window: {cfg.session_start_utc:02d}:00 UTC"
            )

        elapsed    = time.time() - cycle_start
        sleep_time = max(0, cfg.poll_interval - elapsed)
        time.sleep(sleep_time)


if __name__ == "__main__":
    main()
