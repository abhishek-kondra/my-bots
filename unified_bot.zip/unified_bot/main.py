"""
=============================================================================
UNIFIED SIGNAL BOT — 3 Strategies, 1 Process, 1 Telegram Channel
=============================================================================

  Strategy 1 │ Marci Silfrain  — Little RZY (Measured Move)
             │ Symbol: BTCUSDT | TF: 4H trend + 1H execution
             │ Scan: every 15 min | 24/7

  Strategy 2 │ Marco Trades    — Liquidity Sweep
             │ Symbols: XAUUSDT, BTCUSDT | TF: 30m context + 5m entry
             │ Scan: every 1 min | NY Open only (13:00–20:00 UTC)

  Strategy 3 │ Trader Mayne    — Structure & OTE (MSB + OB + Breaker)
             │ Symbols: XAUUSDT, BTCUSDT | TF: 1D HTF + 30m LTF
             │ Scan: every 5 min | 24/7

Data source  : Binance Futures public REST — fapi.binance.com (no API key)
Signals      : Telegram (single bot, single chat)

Setup:
  1. cp .env.example .env
  2. Fill TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env
  3. pip install -r requirements.txt
  4. python main.py
=============================================================================
"""

import os
import time
import logging
import threading
import requests
from datetime import datetime, timezone
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID",   "")
BINANCE_BASE       = "https://fapi.binance.com"

# ── Logging ───────────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/unified_bot.log"),
    ],
)
log = logging.getLogger("main")

from strategies import marci_rzy, marco_liquidity, trader_mayne


# =============================================================================
# SHARED BINANCE FETCHER
# =============================================================================

def fetch_klines(symbol: str, interval: str, limit: int = 200) -> list[dict]:
    """
    Shared fetcher used by all three strategies.
    Returns list of dicts: {ts, open, high, low, close, vol}
    Last (unclosed) candle is INCLUDED — strategies drop it themselves.
    """
    url    = f"{BINANCE_BASE}/fapi/v1/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        return [
            {
                "ts":    r[0],
                "open":  float(r[1]),
                "high":  float(r[2]),
                "low":   float(r[3]),
                "close": float(r[4]),
                "vol":   float(r[5]),
            }
            for r in resp.json()
        ]
    except Exception as exc:
        log.error(f"fetch_klines({symbol},{interval}): {exc}")
        return []


def check_binance() -> bool:
    try:
        r = requests.get(f"{BINANCE_BASE}/fapi/v1/ping", timeout=5)
        r.raise_for_status()
        log.info("✅ Binance Futures API reachable.")
        return True
    except Exception as e:
        log.error(f"❌ Binance Futures API unreachable: {e}")
        return False


# =============================================================================
# TELEGRAM — thread-safe sender
# =============================================================================

_tg_lock = threading.Lock()


def send_telegram(message: str) -> bool:
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        log.warning("Telegram credentials not set — skipping send.")
        return False
    url  = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = {
        "chat_id":    TELEGRAM_CHAT_ID,
        "text":       message,
        "parse_mode": "HTML",
    }
    with _tg_lock:
        try:
            resp = requests.post(url, data=data, timeout=10)
            resp.raise_for_status()
            log.info("✉️  Telegram message sent.")
            return True
        except Exception as exc:
            log.error(f"Telegram send error: {exc}")
            return False


# =============================================================================
# STRATEGY THREADS
# =============================================================================

def run_strategy_1():
    """Marci Silfrain — Little RZY — every 15 min, BTCUSDT only."""
    log.info("[S1-RZY] Thread started.")
    while True:
        try:
            msg, sleep_sec = marci_rzy.run(fetch_klines)
            if msg:
                send_telegram(msg)
        except Exception as exc:
            log.error(f"[S1-RZY] Unhandled error: {exc}", exc_info=True)
            sleep_sec = 900
        log.info(f"[S1-RZY] Next scan in {sleep_sec}s.")
        time.sleep(sleep_sec)


def run_strategy_2():
    """Marco Trades — Liquidity Sweep — every 60s, session-gated."""
    log.info("[S2-MARCO] Thread started.")
    while True:
        try:
            msgs, sleep_sec = marco_liquidity.run(fetch_klines)
            for msg in msgs:
                send_telegram(msg)
                time.sleep(1)
        except Exception as exc:
            log.error(f"[S2-MARCO] Unhandled error: {exc}", exc_info=True)
            sleep_sec = 60
        log.info(f"[S2-MARCO] Next scan in {sleep_sec}s.")
        time.sleep(sleep_sec)


def run_strategy_3():
    """Trader Mayne — Structure & OTE — every 5 min."""
    log.info("[S3-MAYNE] Thread started.")
    while True:
        try:
            msgs, sleep_sec = trader_mayne.run(fetch_klines)
            for msg in msgs:
                send_telegram(msg)
                time.sleep(1)
        except Exception as exc:
            log.error(f"[S3-MAYNE] Unhandled error: {exc}", exc_info=True)
            sleep_sec = 300
        log.info(f"[S3-MAYNE] Next scan in {sleep_sec}s.")
        time.sleep(sleep_sec)


# =============================================================================
# STARTUP BANNER
# =============================================================================

def send_startup_message():
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    msg = (
        "🤖 <b>UNIFIED SIGNAL BOT — ONLINE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🕐 Started : {now}\n"
        f"📡 Data    : Binance Futures (public, no API key)\n\n"
        "📐 <b>Strategy 1 — Little RZY</b>\n"
        "  Marci Silfrain | BTCUSDT\n"
        "  4H trend + 1H execution | Scan: 15 min | 24/7\n\n"
        "💧 <b>Strategy 2 — Liquidity Sweep</b>\n"
        "  Marco Trades | XAUUSDT + BTCUSDT\n"
        "  30m context + 5m entry | Scan: 1 min | NY Open 13–20 UTC\n\n"
        "🔱 <b>Strategy 3 — Structure &amp; OTE</b>\n"
        "  Trader Mayne | XAUUSDT + BTCUSDT\n"
        "  1D HTF + 30m LTF | Scan: 5 min | 24/7\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "⚠️ <i>Signals only — not financial advice.</i>"
    )
    send_telegram(msg)


# =============================================================================
# ENTRY POINT
# =============================================================================

def main():
    log.info("=" * 65)
    log.info("  UNIFIED SIGNAL BOT — 3 Strategies")
    log.info("  S1: Marci Silfrain Little RZY  (BTCUSDT,    4H/1H,   15min)")
    log.info("  S2: Marco Trades Liq Sweep     (XAU+BTC,   30m/5m,   1min, NY session)")
    log.info("  S3: Trader Mayne Structure+OTE (XAU+BTC,   1D/30m,   5min)")
    log.info("=" * 65)

    if not check_binance():
        log.error("Cannot reach Binance Futures API. Check VPS connectivity.")
        return

    send_startup_message()

    threads = [
        threading.Thread(target=run_strategy_1, name="S1-RZY",   daemon=True),
        threading.Thread(target=run_strategy_2, name="S2-MARCO", daemon=True),
        threading.Thread(target=run_strategy_3, name="S3-MAYNE", daemon=True),
    ]
    for t in threads:
        t.start()
        log.info(f"✅ Started thread: {t.name}")

    # Heartbeat — keep main thread alive
    try:
        while True:
            time.sleep(1800)
            alive = [t.name for t in threads if t.is_alive()]
            dead  = [t.name for t in threads if not t.is_alive()]
            log.info(f"💓 Heartbeat — alive: {alive}" + (f" | DEAD: {dead}" if dead else ""))
            if dead:
                send_telegram(
                    f"⚠️ <b>UNIFIED BOT — THREAD DIED</b>\n"
                    f"Dead threads: {dead}\n"
                    f"Alive: {alive}\n"
                    f"Time: {datetime.now(timezone.utc).strftime('%H:%M UTC')}\n"
                    "Consider restarting: <code>pm2 restart unified-bot</code>"
                )
    except KeyboardInterrupt:
        log.info("Shutdown requested. Exiting.")


if __name__ == "__main__":
    main()
